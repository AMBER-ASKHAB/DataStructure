package dbengine.cli;

public class Main {
    public static void main(String[] args) {
        Shell shell = new Shell();
        shell.start();
    }
}
