package dbengine.cli;
import dbengine.query.QueryExecutor;
import dbengine.query.QueryParser;
import dbengine.query.ast.CreateTableNode;
import dbengine.core.DatabaseEngine;

import java.util.Scanner;
public class Shell {
    private final DatabaseEngine engine;
    private final QueryParser parser;
    private final QueryExecutor executor;

    public Shell() {
        this.engine = new DatabaseEngine();
        this.parser = new QueryParser();
        this.executor = new QueryExecutor(engine);
    }

    public void start() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Mini DB Engine REPL. Type CREATE TABLE ... ; or 'exit'.");
        while (true) {
            System.out.print("> ");
            String line = sc.nextLine();
            if (line == null) break;
            if (line.trim().equalsIgnoreCase("exit")) break;
            try {
                CreateTableNode ct = parser.parseCreateTable(line);
                executor.executeCreate(ct);
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        sc.close();
        System.out.println("Goodbye.");
    }
}

