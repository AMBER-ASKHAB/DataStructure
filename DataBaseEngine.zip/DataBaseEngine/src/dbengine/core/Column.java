package dbengine.core;

public class Column {
    public final String name;
    public final String type;
    public final int length;
    public final boolean isPrimary;
    public final boolean isNotNull;

    public Column(String name, String type, int length, boolean isPrimary, boolean isNotNull) {
        this.name = name;
        this.type = type;
        this.length = length;
        this.isPrimary = isPrimary;
        this.isNotNull = isNotNull;
    }

    @Override
    public String toString() {
        if ("VARCHAR".equals(type)) return name + "|" + type + "(" + length + ")" + (isPrimary ? "|PK" : "") + (isNotNull ? "|NN" : "");
        return name + "|" + type + (isPrimary ? "|PK" : "") + (isNotNull ? "|NN" : "");
    }
}
