package dbengine.core;

import dbengine.storage.FileStorageManager;

import java.util.HashMap;
import java.util.Map;

public class DatabaseEngine {
    private Map<String, Table> catalog = new HashMap<>();
    private FileStorageManager storage;

    public DatabaseEngine() {
        try {
            storage = new FileStorageManager("data");
            storage.scanAndLoadTables(this);

        } catch (Exception e) {
            System.out.println("Error starting engine: " + e.getMessage());
        }
    }

    public void createTable(Schema schema) {
        try {
            String tableName = schema.getTableName();
            if (catalog.containsKey(tableName)) {
                System.out.println("Table already exists: " + tableName);
                return;
            }
            if (!validateSchema(schema)) {
                System.out.println("Schema validation failed.");
                return;
            }
            // Create schema + data files
            storage.createTableFiles(schema);
            // Put table into the catalog (memory)
            Table t = new Table(schema);
            catalog.put(tableName, t);

        } catch (Exception e) {
            System.out.println("Error creating table: " + e.getMessage());
        }
    }
    private boolean validateSchema(Schema schema) {
        try {
            // Check duplicate column names
            for (int i = 0; i < schema.getColumns().size(); i++) {
                for (int j = i + 1; j < schema.getColumns().size(); j++) {
                    if (schema.getColumns().get(i).name.equalsIgnoreCase(
                            schema.getColumns().get(j).name)) {
                        System.out.println("Duplicate column: " + schema.getColumns().get(i).name);
                        return false;
                    }
                }
            }

            // Check only one primary key allowed
            int pkCount = 0;
            for (int i = 0; i < schema.getColumns().size(); i++) {
                if (schema.getColumns().get(i).isPrimary) {
                    pkCount++;
                }
            }
            if (pkCount > 1) {
                System.out.println("Only one PRIMARY KEY is allowed.");
                return false;
            }

            // Check types
            for (int i = 0; i < schema.getColumns().size(); i++) {
                String type = schema.getColumns().get(i).type;
                String colName = schema.getColumns().get(i).name;
                int length = schema.getColumns().get(i).length;

                if (!type.equalsIgnoreCase("INT") && !type.equalsIgnoreCase("VARCHAR")) {
                    System.out.println("Unsupported type: " + type);
                    return false;
                }

                if (type.equalsIgnoreCase("VARCHAR")) {
                    if (length <= 0) {
                        System.out.println("Invalid length for VARCHAR: " + colName);
                        return false;
                    }
                }
            }

            return true;

        } catch (Exception e) {
            System.out.println("Error validating schema: " + e.getMessage());
            return false;
        }
    }
    public boolean hasTable(String name) {
        try {
            return catalog.containsKey(name);
        } catch (Exception e) {
            System.out.println("Error checking table: " + e.getMessage());
            return false;
        }
    }

    public Table getTable(String name) {
        try {
            return catalog.get(name);
        } catch (Exception e) {
            System.out.println("Error getting table: " + e.getMessage());
            return null;
        }
    }
    public Map<String, Table> getCatalogSnapshot() {
        try {
            return new HashMap<>(catalog);
        } catch (Exception e) {
            System.out.println("Could not return catalog snapshot.");
            return null;
        }
    }
}
