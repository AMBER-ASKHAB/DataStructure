package dbengine.core;

public class Record {
    private final String[] values;

    public Record(String[] values) {
        this.values = values;
    }

    public String get(int idx) { return values[idx]; }
    public String[] values() { return values; }
    public int size() { return values.length; }
}
