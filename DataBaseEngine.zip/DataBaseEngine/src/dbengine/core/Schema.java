package dbengine.core;

import java.util.ArrayList;
import java.util.List;

public class Schema {
    private final String tableName;
    private final List<Column> columns = new ArrayList<>();
    private Column primaryColumn = null;

    public Schema(String tableName) {
        this.tableName = tableName;
    }
    public String getTableName() { return tableName; }
    public Column getPrimaryColumn() { return primaryColumn; }
    public void addColumn(Column c) {
        columns.add(c);
        if (c.isPrimary) primaryColumn = c;
    }
    public int columnCount() { return columns.size(); }
    //(.size() - no of elements in list)
    public List<Column> getColumns() { return columns; }

    public int findColumnIndex(String name) {
        for (int i = 0; i < columns.size(); i++) {
            if (columns.get(i).name.equalsIgnoreCase(name)) return i;
        }
        return -1;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Schema(").append(tableName).append(")\n");
        for (Column c : columns) sb.append("  ").append(c.toString()).append("\n");
        return sb.toString();
    }
}
