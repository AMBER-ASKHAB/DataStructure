package dbengine.core;

public class Table {
    private final Schema schema;
    private long rowCount = 0;

    public Table(Schema schema) {
        this.schema = schema;
    }
    public Schema getSchema() { return schema; }
    public long getRowCount() { return rowCount; }
    public void incrementRowCount() { rowCount++; }
}
