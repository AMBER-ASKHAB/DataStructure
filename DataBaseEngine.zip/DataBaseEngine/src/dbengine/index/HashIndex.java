package dbengine.index;

public class HashIndex {
}
