package dbengine.query;
import dbengine.core.Column;
import dbengine.core.DatabaseEngine;
import dbengine.query.ast.CreateTableNode;
import dbengine.core.Schema;

public class QueryExecutor {
    private final DatabaseEngine engine;

    public QueryExecutor(DatabaseEngine engine) {
        this.engine = engine;
    }

    public void executeCreate(CreateTableNode node) {
        try {
            Schema schema = new Schema(node.tableName);
            for (int i = 0; i < node.columns.size(); i++) {
                CreateTableNode.ColumnDef col = node.columns.get(i);
                schema.addColumn(new Column(
                        col.name, col.type, col.length, col.primary, col.notNull
                ));
            }
            engine.createTable(schema);
            System.out.println("Table '" + node.tableName + "' created successfully.");

        } catch (Exception e) {
            System.out.println("CREATE TABLE failed: " + e.getMessage());
        }
    }
}
