package dbengine.query;
import dbengine.query.ast.CreateTableNode;
import java.util.List;

    public class QueryParser {
        public CreateTableNode parseCreateTable(String sql) {

            try {
                Tokenizer tz = new Tokenizer(sql);
                List<String> tokens = tz.tokenize();
                if (tokens.size() == 0) throw new Exception("Empty SQL");
                int pos = 0;

                // --- CREATE TABLE ---
                if (!next(tokens, pos++).equalsIgnoreCase("CREATE"))
                    throw new Exception("Expected CREATE");

                if (!next(tokens, pos++).equalsIgnoreCase("TABLE"))
                    throw new Exception("Expected TABLE");
                String tableName = next(tokens, pos++);
                if (!isValidIdentifier(tableName))
                    throw new Exception("Invalid table name: " + tableName);

                if (!next(tokens, pos++).equals("("))
                    throw new Exception("Expected '('");

                CreateTableNode node = new CreateTableNode(tableName);
                while (pos < tokens.size()) {

                    String t = next(tokens, pos++);

                    if (t.equals(")")) break;

                    if (!isValidIdentifier(t))
                        throw new Exception("Invalid column name: " + t);

                    String colName = t;
                    String type = next(tokens, pos++).toUpperCase();

                    int varcharLen = -1;
                    if (type.equals("VARCHAR")) {

                        if (!next(tokens, pos++).equals("("))
                            throw new Exception("Expected '(' after VARCHAR");

                        String number = next(tokens, pos++);
                        varcharLen = Integer.parseInt(number);

                        if (!next(tokens, pos++).equals(")"))
                            throw new Exception("Expected ')' after VARCHAR length");

                    } else if (!type.equals("INT")) {
                        throw new Exception("Unsupported type: " + type);
                    }
                    boolean primary = false, notNull = false;

                    if (pos < tokens.size()) {
                        String peek = tokens.get(pos);

                        if (peek.equalsIgnoreCase("PRIMARY")) {
                            pos++;
                            if (!next(tokens, pos++).equalsIgnoreCase("KEY"))
                                throw new Exception("Expected KEY");
                            primary = true;

                        } else if (peek.equalsIgnoreCase("NOT")) {
                            pos++;
                            if (!next(tokens, pos++).equalsIgnoreCase("NULL"))
                                throw new Exception("Expected NULL");
                            notNull = true;
                        }
                    }

                    node.columns.add(new CreateTableNode.ColumnDef(
                            colName, type, varcharLen, primary, notNull
                    ));
                    System.out.println(node.columns.size());
                    if (pos >= tokens.size())
                        throw new Exception("Unexpected end after column");
                    String sep = tokens.get(pos);

                    if (sep.equals(",")) {
                        pos++;
                    } else if (sep.equals(")")) {
                        pos++;
                        break;
                    }
                }
                return node;
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            return null;
        }
        private String next(List<String> tokens, int idx) throws Exception {
            if (idx >= tokens.size()) throw new Exception("Unexpected end");
            return tokens.get(idx);
        }
        private boolean isValidIdentifier(String s) {
            if (s == null || s.length() == 0) return false;

            char first = s.charAt(0);
            if (!((first >= 'A' && first <= 'Z') || (first >= 'a' && first <= 'z') || first == '_'))
                return false;

            for (int i = 1; i < s.length(); i++) {
                char c = s.charAt(i);
                if (!((c >= 'A' && c <= 'Z') ||
                        (c >= 'a' && c <= 'z') ||
                        (c >= '0' && c <= '9') ||
                        c == '_'))
                    return false;
            }

            return true;
        }

    }

