package dbengine.query;

import java.util.ArrayList;
import java.util.List;

public class Tokenizer {
    private String input;
    private int pos;

    public Tokenizer(String input) {
        this.input = input;
        this.pos = 0;
    }

    public List<String> tokenize() {
        List<String> tokens = new ArrayList<String>();

        while (pos < input.length()) {
            while (pos < input.length() && (input.charAt(pos) == ' ' || input.charAt(pos) == '\t' || input.charAt(pos) == '\n')) {
                pos++;
            }
            if (pos >= input.length()) break;
            char c = input.charAt(pos);
            // Check for single-character symbols
            if (c == '(' || c == ')' || c == ',' || c == ';') {
                tokens.add("" + c);
                pos++;
                continue;
            }

            String word = "";
            while (pos < input.length()) {
                char ch = input.charAt(pos);
                if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '_') {
                    word = word + ch;
                    pos++;
                } else {
                    break;
                }
            }
            if (!word.equals("")) tokens.add(word);
            else pos++;
        }
        return tokens;
    }
}
