package dbengine.query.ast;

import java.util.ArrayList;
import java.util.List;

public class CreateTableNode {
    public final String tableName;
    public final List<ColumnDef> columns = new ArrayList<>();

    public CreateTableNode(String tableName) {
        this.tableName = tableName;
    }

    public static class ColumnDef {
        public final String name;
        public final String type;
        public final int length;
        public final boolean primary;
        public final boolean notNull;

        public ColumnDef(String name, String type, int length, boolean primary, boolean notNull) {
            this.name = name;
            this.type = type;
            this.length = length;
            this.primary = primary;
            this.notNull = notNull;
        }
    }
}
