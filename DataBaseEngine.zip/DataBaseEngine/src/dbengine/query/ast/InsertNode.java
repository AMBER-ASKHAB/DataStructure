package dbengine.query.ast;
import java.util.List;

public class InsertNode {
    private final String tableName;
    private final List<String> values;

    public InsertNode(String tableName, List<String> values) {
        this.tableName = tableName;
        this.values = values;
    }

    public String getTableName() { return tableName; }
    public List<String> getValues() { return values; }
}
