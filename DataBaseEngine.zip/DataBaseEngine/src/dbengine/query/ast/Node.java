package dbengine.query.ast;

public class Node {
}
