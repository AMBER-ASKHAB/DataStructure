package dbengine.storage;
import dbengine.core.Schema;
import dbengine.core.DatabaseEngine;
import dbengine.core.Column;
import java.io.*;

public class FileStorageManager {
    private final String basedir;
    public FileStorageManager(String path){
        this.basedir = path;
        File dir = new File(basedir);
        if(!dir.exists()){
            dir.mkdir();

        }
    }
    public void createTableFiles(Schema schema) {
        try {
            String tableName = schema.getTableName();
            File tableDir = new File(basedir + "/" + tableName);
            if (tableDir.exists()) {
                System.out.println("Table already exists: " + tableName);
                return;
            }
            tableDir.mkdir();
            // creating schema tablename and column name
            File schemaFile = new File(tableDir, "schema.txt");
            try {
                FileWriter fw = new FileWriter(schemaFile);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write("table = "+ tableName);
                bw.newLine();
                for(int i=0; i<schema.getColumns().size(); i++){
                    bw.write(schema.getColumns().get(i).toString());
                    bw.newLine();
                }
                bw.close();
            } catch (Exception e) {
                System.out.println("Error writing schema.txt: " + e.getMessage());
            }
            // -------- CREATE empty data.dat --------
            try
            {
                File datafile=new File(tableDir,"data.dat");
                datafile.createNewFile();
            }catch (Exception e) {
                System.out.println("Error creating data.dat:  " + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("Error creating table files: " + e.getMessage());
        }
    }

    // LOAD ALL TABLES FROM DISK WHEN PROGRAM STARTS
    public void scanAndLoadTables(DatabaseEngine engine) {
        try {
            File folder = new File(basedir);
            File[] tables = folder.listFiles();

            if (tables == null) return;

            for (File tableDir : tables) {
                if (!tableDir.isDirectory()) continue;

                File schemaFile = new File(tableDir, "schema.txt");
                if (!schemaFile.exists()) continue;

                Schema schema = loadSchemaFromFile(schemaFile);

                if (!engine.hasTable(schema.getTableName())) {
                    try {
                        engine.createTable(schema);
                    } catch (Exception e) {
                        System.out.println("Error in scanning tables " + e.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error scanning base directory: " + e.getMessage());
        }

    }
    // READ SCHEMA.TXT BACK TO JAVA
    private Schema loadSchemaFromFile(File schemaFile) {
        try {
            FileReader fr = new FileReader(schemaFile);
            BufferedReader br = new BufferedReader(fr);

            String header = br.readLine();
            if (header == null || !header.startsWith("table=")) {
                br.close();
                return null;
            }

            String tableName = header.substring(6);
            Schema schema = new Schema(tableName);

            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().equals("")) continue;
                String[] parts = line.split("\\|");

                String colName = parts[0];
                String typePart = parts[1];

                boolean pk = line.contains("PK");
                boolean nn = line.contains("NN");

                if (typePart.startsWith("VARCHAR")) {
                    int start = typePart.indexOf("(");
                    int end = typePart.indexOf(")");
                    int len = Integer.parseInt(typePart.substring(start + 1, end));

                    schema.addColumn(new Column(colName, "VARCHAR", len, pk, nn));

                } else {
                    schema.addColumn(new Column(colName, typePart, -1, pk, nn));
                }
            }

            br.close();
            return schema;

        } catch (Exception e) {
            System.out.println("Error reading schema: " + e.getMessage());
            return null;
        }
    }

}
