package dbengine.utils;
import java.io.File;
public class FileUtils {
    public static void ensureDir(String path) {
        File f = new File(path);
        if (!f.exists()) f.mkdirs();
    }

    public static void deleteDirectory(File dir) {
        if (dir == null || !dir.exists()) return;
        if (dir.isDirectory()) {
            File[] children = dir.listFiles();
            if (children != null) {
                for (File c : children) deleteDirectory(c);
            }
        }
        dir.delete();
    }
}
