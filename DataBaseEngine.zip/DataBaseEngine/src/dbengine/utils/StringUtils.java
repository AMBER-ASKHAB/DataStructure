package dbengine.utils;

public class StringUtils {
}
