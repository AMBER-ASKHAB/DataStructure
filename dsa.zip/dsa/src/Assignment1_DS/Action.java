package Assignment1_DS;

public class Action {
    String type ;
    book b;
    int index;
    Action next;
    public Action(String type, book b, int index)
    {
        this.type=type;
        this.b=b;
        this.index=index;
    }
}
