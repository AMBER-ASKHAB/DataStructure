package Assignment1_DS;

import java.util.Stack;

public class Array_functions {

    book[] book = new book[10];
    stack undo = new stack();
    stack redo = new stack();
    int c = 0;

    Array_functions() {
        for (int i = 0; i < book.length; i++) {
            book[i] = new book();
        }
    }

    private void insertAt(int index, book b, boolean record) {
        if (c == book.length) {
            System.out.println("Book cannot be inserted (Array full)");
            return;
        }
        for (int i = c; i > index; i--)
            book[i] = book[i - 1];

        book[index] = b;
        c++;

        if (record) {
            undo.push(new Action("insert", b, index));
            redo.clear();
        }
    }

    private void deleteAt(int index, boolean record) {
        if (c == 0) {
            System.out.println("Nothing to delete");
            return;
        }
        book deleted = book[index];
        for (int i = index; i < c - 1; i++)
            book[i] = book[i + 1];

        book[c - 1] = new book();
        c--;

        if (record) {
            undo.push(new Action("delete", deleted, index));
            redo.clear();
        }
    }

    public void undo() {
        if (undo.isEmpty()) {
            System.out.println("Nothing to undo");
            return;
        }

       Action a =undo.pop();

        if (a.type.equalsIgnoreCase("insert"))
        {
            deleteAt(a.index, false);
            a.type="delete";
        }


        else if (a.type.equalsIgnoreCase("delete"))
        {
            insertAt(a.index, a.b, false);
            a.type="insert";
        }
        redo.push(a);
    }

    public void redo() {
        if (redo.isEmpty()) {
            System.out.println("Nothing to redo");
            return;
        }
        Action a = redo.pop();
        if (a.type.equalsIgnoreCase("insert"))
            deleteAt(a.index, false);

        else if (a.type.equalsIgnoreCase("delete"))
            insertAt(a.index, a.b, false);

        undo.push(a);
    }

    public void insertAtFront(book b) {
        if (c == 10) {
            System.out.println("ARRAY IS FULL");
            return;
        }

        for (int i = 0; i < c; i++) {
            if (b.bEdition == book[i].bEdition &&
                    b.btitle.equalsIgnoreCase(book[i].btitle)) {
                book[i].noOfCopies++;
                return;
            }
        }

        insertAt(0, b, true);
    }

    public void insertAtEnd(book b) {
        if (c == 10) {
            System.out.println("ARRAY IS FULL");
            return;
        }

        for (int i = 0; i < c; i++) {
            if (b.bEdition == book[i].bEdition &&
                    b.btitle.equalsIgnoreCase(book[i].btitle)) {
                book[i].noOfCopies++;
                return;
            }
        }

        insertAt(c, b, true);
    }

    public void insertBeforeTitle(String title, book b) {
        if (c == 10) {
            System.out.println("ARRAY IS FULL");
            return;
        }
        int pos = -1;
        for (int i = 0; i < c; i++) {
            if (title.equalsIgnoreCase(book[i].btitle)) {
                pos = i;
                break;
            }
        }
        if (pos == -1) {
            System.out.println("Title not found, inserting at end");
            insertAt(c, b, true);
        } else {
            insertAt(pos, b, true);
        }
    }

    public void deleteFromFront() {
        if (c == 0) {
            System.out.println("ARRAY IS EMPTY");
            return;
        }

        if (book[0].noOfCopies > 1)
            book[0].noOfCopies--;
        else
            deleteAt(0, true);
    }

    public void delFromEnd() {
        if (c == 0) {
            System.out.println("ARRAY IS EMPTY");
            return;
        }

        if (book[c - 1].noOfCopies > 1) {
            book[c - 1].noOfCopies--;
        } else {
            deleteAt(c - 1, true);
        }
    }

    public void delBookAgainstTitle(String title) {
        if (c == 0) {
            System.out.println("ARRAY IS EMPTY");
            return;
        }

        for (int i = 0; i < c; i++) {
            if (title.equalsIgnoreCase(book[i].btitle)) {

                if (book[i].noOfCopies > 1) {
                    book[i].noOfCopies--;
                } else {
                    deleteAt(i, true);
                }
                return;
            }
        }

        System.out.println("Title not found");
    }

    public void displayAll() {
        for (int i = 0; i < c; i++) {
            System.out.println(book[i].btitle);
        }
    }

    public void displayBySubject(String subject) {
        for (int i = 0; i < c; i++) {
            if (book[i].btitle.equalsIgnoreCase(subject)) {
                System.out.println(book[i].btitle);
            }
        }
    }
}
