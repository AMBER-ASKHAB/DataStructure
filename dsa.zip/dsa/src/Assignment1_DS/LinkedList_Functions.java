package Assignment1_DS;

import java.util.Stack;

public class LinkedList_Functions {
    Node start = null;
    int c = 0;
    stack undo = new stack();
    stack redo = new stack();

    private void insertAt(int index, book b, boolean record) {
        Node newNode = new Node(new book(b));
        if (index == 0) {
            newNode.next = start;
            start = newNode;
        } else {
            Node temp =start;
            for (int i = 0; i < index-1; i++)
                temp = temp.next;

            newNode.next = temp.next;
            temp.next = newNode;
        }
        c++;
        if (record) {
            undo.push(new Action("insert", b, index));
            redo.clear();
        }
    }

    private void deleteAt(int index, boolean record) {
        if (c == 0) {
            System.out.println("Nothing to delete.");
            return;
        }
        Node deleted;
        if (index == 0) {
            deleted = start;
            start = start.next;
        } else {
            Node temp = start;

            for (int i = 0; i < index-1; i++)
                temp = temp.next;

            deleted = temp.next;
            temp.next = temp.next.next;
        }
        c--;
        if (record) {
            undo.push(new Action("delete", deleted.data, index));
            redo.clear();
        }
    }

    public void undo() {
        if (undo.isEmpty()) {
            System.out.println("Nothing to undo");
            return;
        }
        Action a = undo.pop();
        if (a.type.equalsIgnoreCase("insert"))
        {
            a.type="insert";
            deleteAt(a.index, false);
        }
        else if (a.type.equalsIgnoreCase("delete"))
        {
            a.type="insert";
            insertAt(a.index, a.b, false);
        }
        redo.push(a);
    }

    public void redo() {
        if (redo.isEmpty()) {
            System.out.println("Nothing to redo");
            return;
        }
        Action a = redo.pop();
        if (a.type.equalsIgnoreCase("insert"))
            deleteAt(a.index, false);
        else if (a.type.equalsIgnoreCase("delete"))
            insertAt(a.index, a.b, false);
        undo.push(a);
    }

    public void insertAtFront(book b) {
        Node temp = start;
        while (temp != null) {
            if (temp.data.bEdition == b.bEdition &&
                    temp.data.btitle.equalsIgnoreCase(b.btitle)) {
                temp.data.noOfCopies++;
                return;
            }
            temp = temp.next;
        }
        insertAt(0, b, true);
    }

    public void insertAtEnd(book b) {
        Node temp = start;
        while (temp != null) {
            if (temp.data.bEdition == b.bEdition &&
                    temp.data.btitle.equalsIgnoreCase(b.btitle)) {
                temp.data.noOfCopies++;
                return;
            }
            temp = temp.next;
        }
        insertAt(c, b, true);
    }

    public void insertBeforeTitle(String title, book b) {
        Node temp = start;
        int index = 0;
        while (temp != null) {
            if (temp.data.btitle.equalsIgnoreCase(title)) {
                insertAt(index, b, true);
                return;
            }
            index++;
            temp = temp.next;
        }
    }

    public void deleteFromFront() {
        if (c == 0) {
            System.out.println("List is empty");
            return;
        }
        if (start.data.noOfCopies > 1)
            start.data.noOfCopies--;
        else
            deleteAt(0, true);
    }
    public void delFromEnd() {
        if (c == 0) {
            System.out.println("List is empty");
            return;
        }
        if (getNode(c - 1).data.noOfCopies > 1) {
            getNode(c - 1).data.noOfCopies--;
        } else {
            deleteAt(c - 1, true);
        }
    }

    private Node getNode(int index) {
        Node t = start;
        for (int i = 0; i < index; i++)
              t = t.next;
        return t;
    }

    public void delBookAgainstTitle(String title) {
        Node temp =start;
        int index = 0;

        while (temp != null) {
            if (temp.data.btitle.equalsIgnoreCase(title)) {
                if (temp.data.noOfCopies > 1)
                    temp.data.noOfCopies--;
                else
                    deleteAt(index, true);
                return;
            }
            index++;
            temp = temp.next;
        }

        System.out.println("Title not found.");
    }
    public void displayAll() {
        Node t = start;
        while (t != null) {
            System.out.println(t.data.btitle);
            t = t.next;
        }
    }

    public void displayBySubject(String subject) {
        Node t = start;
        while (t != null) {
            if (t.data.btitle.equalsIgnoreCase(subject))
                System.out.println(t.data.btitle);
            t = t.next;
        }
    }
}

