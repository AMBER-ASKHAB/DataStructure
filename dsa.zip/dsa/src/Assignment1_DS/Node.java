package Assignment1_DS;

public class Node {
    book data;
    Node next;

    Node(book b) {
        this.data = b;
        this.next = null;
    }
}
