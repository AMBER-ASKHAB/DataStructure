package Assignment1_DS;

public class book {
    int bId;
    int bprice;
    String btitle;
    String bEdition;
    int noOfCopies=0;
    String subject;


    book(int bid, int bprice, String btitle, String bEdition, String subject)
    {
       this.bId = bid;
       this.bprice = bprice;
       this.btitle = btitle;
       this.bEdition = bEdition;
       this.subject = subject;
       this.noOfCopies = 0;
    }
    book()
    {

    }
    book(book b) {
        this.bId =b.bId;
        this.bprice = b.bprice;
        this.btitle = b.btitle;
        this.bEdition = b.bEdition;
        this.subject = b.subject;
        this.noOfCopies = b.noOfCopies;
    }
}



