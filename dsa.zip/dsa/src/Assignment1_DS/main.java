
package Assignment1_DS;

import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        Array_functions list = new Array_functions();

        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- BOOK MANAGEMENT MENU ---");
            System.out.println("1. Insert at Front");
            System.out.println("2. Insert at End");
            System.out.println("3. Insert Before Title");
            System.out.println("4. Delete from Front");
            System.out.println("5. Delete from End");
            System.out.println("6. Delete Book by Title");
            System.out.println("7. Display All Books");
            System.out.println("8. Display Books by Title");
            System.out.println("9. Undo");
            System.out.println("10. Redo");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1: {
                    book b = new book();
                    System.out.print("Enter book title: ");
                    b.btitle = sc.nextLine();
                    System.out.print("Enter edition: ");
                    b.bEdition = sc.next();
                    System.out.print("Enter number of copies: ");
                    b.noOfCopies = sc.nextInt();
                    sc.nextLine(); // consume newline
                    list.insertAtFront(b);
                    break;
                }

                case 2: {
                    book b = new book();
                    System.out.print("Enter book title: ");
                    b.btitle = sc.nextLine();
                    System.out.print("Enter edition: ");
                    b.bEdition = sc.next();
                    System.out.print("Enter number of copies: ");
                    b.noOfCopies = sc.nextInt();
                    sc.nextLine();
                    list.insertAtEnd(b);
                    break;
                }

                case 3: {
                    book b = new book();
                    System.out.print("Enter book title to insert: ");
                    b.btitle = sc.nextLine();
                    System.out.print("Enter edition: ");
                    b.bEdition = sc.next();
                    System.out.print("Enter number of copies: ");
                    b.noOfCopies = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter existing title to insert before: ");
                    String title = sc.nextLine();
                    list.insertBeforeTitle(title, b);
                    break;
                }

                case 4:
                    list.deleteFromFront();
                    break;

                case 5:
                    list.delFromEnd();
                    break;

                case 6:
                    System.out.print("Enter title to delete: ");
                    String title = sc.nextLine();
                    list.delBookAgainstTitle(title);
                    break;

                case 7:
                    System.out.println("\nAll books:");
                    list.displayAll();
                    break;

                case 8:
                    System.out.print("Enter title to search: ");
                    String sub = sc.nextLine();
                    list.displayBySubject(sub);
                    break;

                case 9:
                    list.undo();
                    break;

                case 10:
                    list.redo();
                    break;

                case 0:
                    System.out.println("Exiting program...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 0);

        sc.close();
    }
}
