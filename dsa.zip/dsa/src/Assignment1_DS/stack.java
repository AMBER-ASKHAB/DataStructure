package Assignment1_DS;

import undo_Redo.node;

class stack {
    Action start;
    public void push(Action newNode) {
       if(start==null)
         start=newNode;
       else
           newNode.next=start;
            start=newNode;
    }

    public Action pop() {
        if(start==null)
            return null;
        Action temp=start;
        start=start.next;
        return  temp;
    }

    public Action peek() {
        return start;
    }

    public boolean isEmpty() {
        return start == null;
    }

    public void clear() {
        start = null;
    }
}