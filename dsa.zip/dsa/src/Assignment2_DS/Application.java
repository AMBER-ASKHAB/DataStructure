package Assignment2_DS;

class Application {
    String name;
    String address;
    String contact;
    String gender;
    double requiredAmount;
    Application next;
    Application()
    {}
    Application(String name, String address, String contact, String gender, double requiredAmount) {
        this.name = name;
        this.address = address;
        this.contact = contact;
        this.gender = gender.toLowerCase();
        this.requiredAmount = requiredAmount;
    }
    public void print() {
        System.out.println(" Name: " + name +
                ", Gender: " + gender + ", Amount: " + requiredAmount);
    }
}