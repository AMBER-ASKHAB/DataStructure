package Assignment2_DS;

import java.util.Scanner;

public class LMS {
    PQUEUE appList;
    PQUEUE rejectedList;
    PQUEUE maleAcceptedList;
    PQUEUE femaleAcceptedList;
    PQUEUE approvedList;
    PQUEUE disApprovedList;
    PQUEUE successLoanRecieverList;
    PQUEUE discardedList;

    Scanner sc = new Scanner(System.in);
    int idCounter = 1;

    LMS() {
        System.out.println("WHICH DATA STRUCTURE YOU WANT TO USE? (Array / LinkedList)");
        String ds = sc.next();

        boolean useArray = ds.equalsIgnoreCase("array");

        appList = useArray ? new QueueA() : new QueueL();
        rejectedList = useArray ? new QueueA() : new QueueL();
        maleAcceptedList = useArray ? new QueueA() : new QueueL();
        femaleAcceptedList = useArray ? new QueueA() : new QueueL();
        approvedList = useArray ? new QueueA() : new QueueL();
        disApprovedList = useArray ? new QueueA() : new QueueL();
        successLoanRecieverList = useArray ? new QueueA() : new QueueL();
        discardedList = useArray ? new QueueA() : new QueueL();
    }

    public void AddApplication(Application a) {
        appList.enqueue(a);
        System.out.println("Application Added!");
    }

    public void showApplicantList() {
        appList.display();
    }

    public void initialScreening(boolean accept) {
        Application a = appList.dequeue();
        if (a == null) {
            System.out.println("No applications to process.");
            return;
        }

        if (accept) {
            if (a.gender.equalsIgnoreCase("male"))
                maleAcceptedList.enqueue(a);
            else
                femaleAcceptedList.enqueue(a);

            System.out.println("Application Accepted!");
        } else {
            rejectedList.enqueue(a);
            System.out.println("Application Moved to Rejected List.");
        }
    }

    public void showAcceptedLists() {
        System.out.println("-- Male Accepted --");
        maleAcceptedList.display();

        System.out.println("-- Female Accepted --");
        femaleAcceptedList.display();
    }

    public void showRejectedList() {
        rejectedList.display();
    }

    public void finalApproval(boolean approve, boolean isMale) {
        PQUEUE list = isMale ? maleAcceptedList : femaleAcceptedList;
        Application a = list.dequeue();

        if (a == null) {
            System.out.println("No accepted applicants available.");
            return;
        }

        if (approve) {
            approvedList.enqueue(a);
            System.out.println("Approved!");
        } else {
            disApprovedList.enqueue(a);
            System.out.println("Disapproved!");
        }
    }

    private boolean consultApplicant(Application a) {
        return a.requiredAmount < 500000;
    }

    public void dispatchLoan() {
        if (!approvedList.isEmpty()) {
            Application a = approvedList.dequeue();
            successLoanRecieverList.enqueue(a);
            System.out.println("Loan dispatched for " + a.name);
        }

        if (!disApprovedList.isEmpty()) {
            Application d = disApprovedList.dequeue();
            System.out.println("Reprocessing Disapproved: " + d.name);

            if (consultApplicant(d)) {
                approvedList.enqueue(d);
                System.out.println("Fixed , Moved to Approved List");
            } else {
                discardedList.enqueue(d);
                System.out.println("Not Fixed , Moved to Discarded List");
            }
            return;
        }

        if (!discardedList.isEmpty()) {
            Application x = discardedList.dequeue();
            System.out.println("Reprocessing Discarded: " + x.name);

            if (consultApplicant(x)) {
                if (x.gender.equalsIgnoreCase("male"))
                    maleAcceptedList.enqueue(x);
                else
                    femaleAcceptedList.enqueue(x);

                System.out.println("Moved to Accepted List");
            } else {
                rejectedList.enqueue(x);
                System.out.println("Moved to Rejected List");
            }
            return;
        }

        System.out.println("Nothing left to process.");
    }

    public void showSuccessful() {
        successLoanRecieverList.display();
    }

    public void showDiscarded() {
        discardedList.display();
    }
}
