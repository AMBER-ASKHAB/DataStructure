package Assignment2_DS;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        LMS sys = new LMS();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=====  BANK LOAN MENU =====");
            System.out.println("1. Add new loan application");
            System.out.println("2. Show applicant list");
            System.out.println("3. Accept/Reject application");
            System.out.println("4. Show accepted lists");
            System.out.println("5. Show rejected list");
            System.out.println("6. Approve/Disapprove application");
            System.out.println("7. Dispatch loan");
            System.out.println("8. Show successful loan receivers");
            System.out.println("9. Show discarded list");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");

            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1:
                    System.out.print("Name: ");
                    String n = sc.nextLine();
                    System.out.print("Address: ");
                    String ad = sc.nextLine();
                    System.out.print("Contact: ");
                    String c = sc.nextLine();
                    System.out.print("Gender (male/female): ");
                    String g = sc.nextLine();
                    System.out.print("Required Amount: ");
                    double amt = sc.nextDouble();
                    Application a = new Application(n, ad, c, g, amt);
                    sys.AddApplication(a);
                    break;

                case 2:
                   sys.showApplicantList();
                    break;

                case 3:
                    System.out.print("Accept? (1=yes / 0=no): ");
                    int s = sc.nextInt();
                    if(s == 0) {
                        sys.initialScreening(false);
                    }else if(s==1) {
                        sys.initialScreening(true);
                    }else {
                        System.out.println("Invalid choice.");
                    }

                    break;

                case 4:
                   sys.showAcceptedLists();
                    break;

                case 5:
                    sys.showRejectedList();
                    break;

                case 6:
                    System.out.print("Approve? (1/0): ");
                    boolean approve = sc.nextInt() == 1;

                    System.out.print("From male list? (1=yes / 0=no): ");
                    boolean male = sc.nextInt() == 1;

                  sys.finalApproval(approve, male);
                    break;

                case 7:
                   sys.dispatchLoan();
                    break;

                case 8:
                    sys.showSuccessful();
                    break;

                case 9:
                   sys.showDiscarded();
                    break;

                case 0:
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
