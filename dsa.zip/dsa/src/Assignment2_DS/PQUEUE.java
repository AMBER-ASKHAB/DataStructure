package Assignment2_DS;

public abstract class PQUEUE {
    public abstract boolean isEmpty();
    public abstract void enqueue(Application obj);
    public abstract Application dequeue() ;
    public abstract void display() ;


}
