package Assignment2_DS;

import queue_ViaArray.customer;

public class QueueA extends PQUEUE {
    Application[] C=new   Application[3];
    int count=0;
    int flag=0;
    int d=0;
    int c=0;
    QueueA(){
        for(int i=0;i<3;i++){
            C[i]=new Application();
        }
    }
    public boolean isEmpty()
    {
        if(count==0)
            return true;
        else
            return false;
    }
    public void enqueue(Application obj) {
        if (c == d && flag == 1) {
            System.out.println("Queue is full! You can't insert Application =" + obj.name);
            return;
        }

        C[c] = obj;
        count++;
        System.out.println("Inserted Application =" + obj.name + " at index " + c);

        if (c == C.length - 1) {
            c = 0;
            flag = 1;
        } else {
            c++;
        }

        //System.out.println("c =" + c + ", d=" + d + ", flag=" + flag + ", count=" + count);
    }
    public Application dequeue() {
        if (c == d && flag == 0) {
            System.out.println("Queue is empty!");
            return null;
        }

        Application temp = C[d];
        System.out.println("Removed Application =" + temp.name + " from index " + d);
        count--;


        if (d == C.length - 1) {
            d = 0;
            flag = 0;
        } else {
            d++;
        }

       // System.out.println("c=" + c + ", d=" + d + ", flag=" + flag + ", count=" + count);
        return temp;
    }

    public void display() {
        if (c == d && flag == 0) {
            System.out.println("All Applications have been processed!.");
            return;
        }

        System.out.println("Remaining Coustomers:");

        if (c == d && flag == 1) {
            for (int i = 0; i < C.length; i++) {
                printCustomer(C[i]);
            }

        } else if (c < d && flag == 1) {
            for (int i = d; i < C.length; i++) {
                printCustomer(C[i]);
            }
            for (int i = 0; i < c; i++) {
                printCustomer(C[i]);
            }
        } else if (c > d && flag == 0) {
            for (int i = d; i < c; i++) {
                printCustomer(C[i]);
            }
        }
    }

    private void printCustomer(Application comp) {
        System.out.println( "Name: " + comp.name + " | Gender: " + comp.gender + " | Amount: " + comp.requiredAmount);
    }
}
