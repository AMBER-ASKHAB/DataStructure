package Assignment2_DS;

public class QueueL extends PQUEUE {
    Application start;
    Application end;

    public void enqueue(Application n) {
        if (start == null) {
            start = n;
            end = n;
        } else {
            end.next = n;
            end = end.next;
        }
    }

    public Application dequeue() {
        if (start == null) {
            System.out.println("Queue is empty");
            return null;
        } else {
            Application temp = start;
            start = start.next;
            temp.next = null;
            return temp;
        }
    }

    @Override
    public void display() {
        if (start == null) {
            System.out.println("Queue is empty");
            return;
        }
        Application temp = start;
        while (temp != null) {
            temp.print();
            temp = temp.next;
        }
    }

    public boolean isEmpty() {
        return start == null;
    }
}
