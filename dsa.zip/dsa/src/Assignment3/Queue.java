package Assignment3;

public abstract class Queue {
    public abstract void enqueue(customer3 c);
    public abstract boolean isEmpty() ;
    public abstract void displayQueue();
    public abstract void displayYoungest();
    public abstract void displayEldest();
    public abstract void displayAllVIIPs();
    public abstract void displayFemaleNormal();
    public abstract void displayEldestVVIP();
    public abstract void SearchByName(String name) ;
    public abstract customer3 dequeue();
    public abstract int countByType(String type);
    public abstract int sumAgeByType(String type) ;
    public abstract void averageAgeByType(String type) ;
    public abstract void changeType(int id, String type);
    public abstract void changeGender(int id, String gender);

}
