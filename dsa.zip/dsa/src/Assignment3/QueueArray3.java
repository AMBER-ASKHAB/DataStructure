package Assignment3;

public  class QueueArray3 extends Queue {
    customer3[] queue;
    int size;
    int capacity;

    public QueueArray3(int capacity) {
        this.capacity = capacity;
        this.queue = new customer3[capacity];
        this.size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void enqueue(customer3 c) {
        if (size == capacity) {
            System.out.println("Queue is full! Cannot add customer " + c.cusName);
            return;
        }
        int i;
        for (i = 0; i < size; i++) {
            if (c.priority < queue[i].priority)
                break;
        }

        for (int j = size; j > i; j--) {
            queue[j] = queue[j - 1];
        }

        queue[i] = c;
        size++;
        System.out.println("Customer added: " + c.cusName);
    }

    public customer3 dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty!");
            return null;
        }

        customer3 c = queue[0];

        for (int i = 0; i < size - 1; i++) {
            queue[i] = queue[i + 1];
        }
        size--;

        System.out.println("Served Customer: " + c.cusName + " (ID: " + c.cusId + ")");
        return c;
    }


    @Override
    public int countByType(String type) {
        int count = 0;
        for (int i = 0; i < size; i++) {
            if (queue[i].cusType.equalsIgnoreCase(type)) {
                count++;
            }
        }
        return count;
    }

    @Override
    public int sumAgeByType(String type) {
        int sum = 0;
        for (int i = 0; i < size; i++) {
            if (queue[i].cusType.equalsIgnoreCase(type)) {
                sum += queue[i].cusAge;
            }
        }
        return sum;
    }

    public void displayQueue() {
        if (isEmpty()) {
            System.out.println("No customers in queue.");
            return;
        }

        for (int i = 0; i < size; i++) {
            System.out.println(queue[i]);
        }
    }

    public void displayYoungest() {
        if (isEmpty()) {
            System.out.println("No customer to display.");
            return;
        }

        customer3 youngest = queue[0];
        for (int i = 1; i < size; i++) {
            if (queue[i].cusAge < youngest.cusAge) youngest = queue[i];
        }

        System.out.println("Youngest Customer: " + youngest);
    }

    public void displayEldest() {
        if (isEmpty()) {
            System.out.println("No customer to display.");
            return;
        }

        customer3 eldest = null;
        for (int i = 0; i < size; i++) {
            if (queue[i].cusGender.equalsIgnoreCase("male")) {
                if (eldest == null || queue[i].cusAge > eldest.cusAge) eldest = queue[i];
            }
        }

        if (eldest != null) System.out.println("Eldest Male Customer: " + eldest);
        else System.out.println("No male customer found.");
    }

    public void displayAllVIIPs() {
        boolean found = false;
        for (int i = 0; i < size; i++) {
            if (queue[i].cusType.equalsIgnoreCase("VVIP")) {
                System.out.println(queue[i]);
                found = true;
            }
        }
        if (!found) System.out.println("No VVIP customers.");
    }

    // 7. Display normal female
    public void displayFemaleNormal() {
        boolean found = false;
        for (int i = 0; i < size; i++) {
            if (queue[i].cusType.equalsIgnoreCase("Normal") && queue[i].cusGender.equalsIgnoreCase("female")) {
                System.out.println(queue[i]);
                found = true;
            }
        }
        if (!found) System.out.println("No normal female customers.");
    }

    public void displayEldestVVIP() {
        customer3 eldestVIP = null;
        for (int i = 0; i < size; i++) {
            if (queue[i].cusType.equalsIgnoreCase("VIP")) {
                if (eldestVIP == null || queue[i].cusAge > eldestVIP.cusAge) eldestVIP = queue[i];
            }
        }
        if (eldestVIP != null) System.out.println("Eldest VIP Customer: " + eldestVIP);
        else System.out.println("No VIP customer found.");
    }

    public void SearchByName(String name) {
        boolean found = false;
        for (int i = 0; i < size; i++) {
            if (queue[i].cusName.equalsIgnoreCase(name)) {
                System.out.println(queue[i]);
                found = true;
            }
        }
        if (!found) System.out.println("Customer not found.");
    }

    public void averageAgeByType(String type) {
        int sum = 0, count = 0;
        for (int i = 0; i < size; i++) {
            if (queue[i].cusType.equalsIgnoreCase(type)) {
                sum += queue[i].cusAge;
                count++;
            }
        }
        if (count == 0) System.out.println("No customer of type " + type);
        else System.out.println("Average age of " + type + " customers: " + (sum / count));
    }

    public void changeType(int id, String type) {
        for (int i = 0; i < size; i++) {
            if (queue[i].cusId == id) {
                queue[i].cusType = type;
                queue[i].priority = getpriority(queue[i]);
                customer3 c = dequeue();
                enqueue(c);

                System.out.println("Customer type changed successfully.");
                return;
            }
        }
        System.out.println("Customer ID not found.");
    }

    // 12. Change gender
    public void changeGender(int id, String gender) {
        for (int i = 0; i < size; i++) {
            if (queue[i].cusId == id) {
                queue[i].cusGender = gender;
                System.out.println("Customer gender changed successfully.");
                return;
            }
        }
        System.out.println("Customer ID not found.");
    }

    public int getpriority(customer3 c)
    {
        if(c.cusType.equalsIgnoreCase("Normal")&&c.cusGender.equalsIgnoreCase("male"))
            return 5;
        else if(c.cusType.equalsIgnoreCase("VIP") && c.cusGender.equalsIgnoreCase("male"))
            return 4;
        else if(c.cusType.equalsIgnoreCase("Normal") && c.cusGender.equalsIgnoreCase("female"))
            return 3;
        else if(c.cusType.equalsIgnoreCase("VIP") && c.cusGender.equalsIgnoreCase("Female"))
            return 2;
        else if(c.cusType.equalsIgnoreCase("VVIP") &&
                (c.cusGender.equalsIgnoreCase("Female")||
                        c.cusGender.equalsIgnoreCase("male")))
            return 1;
        else
            System.out.println("invalid Type Entered");

        return 0;
    }
}
