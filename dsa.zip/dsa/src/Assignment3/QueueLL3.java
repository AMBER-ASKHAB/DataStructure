package Assignment3;

import priorityQueue_primtive.process;

public class QueueLL3 extends Queue {
    customer3 start;
    customer3 end;

    public void enqueue(customer3 c){
        if(start==null){
            start=c;
            end=c;
        }else if(start.next==null && c.priority<start.priority){
            c.next=start;
            start=c;
        }
        else {
            customer3 temp=start;
            while(temp.next!=null && c.priority >= temp.next.priority){
                temp=temp.next;
            }
            c.next=temp.next;
            temp.next=c;
        }
    }
    public boolean isEmpty() {
        if(start==null)
            return true;
        return false;
    }
    public void displayQueue()
    {
        if(isEmpty()) {
            System.out.println("No pending processes ");
        }else
        {
            customer3 temp=start;
            while(temp!=null)
            {
                System.out.println("ID : "+temp.cusId+", NAME: "+temp.cusName+", PRIORITY: "
                        +temp.priority+ "Age: "+temp.cusAge+", Gender: "+temp.cusGender+ "Type: "+temp.cusType);
                temp=temp.next;
            }
        }
    }
    public void displayYoungest()
   {
     if(isEmpty())
         System.out.println("No customer to display ");
     else {
         customer3 temp=start;
         customer3 youngest=start;
         while(temp.next!=null)
         {
             if(temp.cusAge<youngest.cusAge)
             {
                 youngest=temp;
             }
             temp=temp.next;
         }
         System.out.println("youngest Customer Is: "+youngest.cusId);
         System.out.println("Server Customer : "+"ID : "+youngest.cusId+", NAME: "+youngest.cusName+", PRIORITY: "
                 +youngest.priority+ "Age: "+youngest.cusAge+", Gender: "+youngest.cusGender+ "Type: "+temp.cusType);
     }
   }

    public void displayEldest() {
        if (isEmpty()) {
            System.out.println("No customer to display.");
            return;
        }

        customer3 temp = start;
        customer3 eldest = start;

        while (temp != null) {
            if (temp.cusAge > eldest.cusAge) {
                eldest = temp;
            }
            temp = temp.next;
        }

        System.out.println("Eldest Customer ID: " + eldest.cusId);
        System.out.println("Served Customer: ID: " + eldest.cusId +
                ", NAME: " + eldest.cusName +
                ", PRIORITY: " + eldest.priority +
                ", Age: " + eldest.cusAge +
                ", Gender: " + eldest.cusGender +
                ", Type: " + eldest.cusType);
    }

   public void displayAllVIIPs()
   {
       if (isEmpty()) {
           System.out.println("No customer to display.");
       }else
       {
           customer3 temp=start;
           while(temp!=null)
           {
               if(temp.cusType.equalsIgnoreCase("VVIP"))
               {
                   System.out.println("ID : "+temp.cusId+", NAME: "+temp.cusName+", PRIORITY: "
                           +temp.priority+ "Age: "+temp.cusAge+", Gender: "+temp.cusGender+ "Type: "+temp.cusType);
               }
               temp=temp.next;
           }
       }
   }
    public void displayFemaleNormal()
    {
        if (isEmpty()) {
            System.out.println("No customer to display.");
        }else
        {
            customer3 temp=start;
            while(temp!=null)
            {
                if(temp.cusType.equalsIgnoreCase("normal") && temp.cusGender.equalsIgnoreCase("female"))
                {
                    System.out.println("ID : "+temp.cusId+", NAME: "+temp.cusName+", PRIORITY: "
                            +temp.priority+ "Age: "+temp.cusAge+", Gender: "+temp.cusGender+ "Type: "+temp.cusType);
                }
                temp=temp.next;
            }
        }
    }
    public void displayEldestVVIP() {
        if (isEmpty()) {
            System.out.println("No customer to display.");
            return;
        }

        customer3 temp = start;
        customer3 eldest = start;

        while (temp != null) {
            if (temp.cusAge > eldest.cusAge) {
                eldest = temp;
            }
            temp = temp.next;
        }
        if(eldest.cusType.equalsIgnoreCase("VIP"))
        {
            System.out.println("Eldest Customer ID: " + eldest.cusId);
            System.out.println("Served Customer: ID: " + eldest.cusId +
                    ", NAME: " + eldest.cusName +
                    ", PRIORITY: " + eldest.priority +
                    ", Age: " + eldest.cusAge +
                    ", Gender: " + eldest.cusGender +
                    ", Type: " + eldest.cusType);
        }else
        {
            System.out.println("no VIP ");
        }

    }

    public void SearchByName(String name) {
        if(isEmpty())
        {
            System.out.println("No customer to display.");
        }else
        {
            customer3 temp=start;
            while(temp!=null)
            {
                if(temp.cusName.equalsIgnoreCase(name))
                {
                    System.out.println("ID : "+temp.cusId+", NAME: "+temp.cusName+", PRIORITY: "
                            +temp.priority+ "Age: "+temp.cusAge+", Gender: "+temp.cusGender+ "Type: "+temp.cusType);
                }
                temp=temp.next;
            }
        }

    }
    public customer3 dequeue(){
        if(isEmpty()) {
            System.out.println("queue is empty");
        }else
        {
            customer3 temp=start;
            start=start.next;
            System.out.println("Server Customer : "+"ID : "+temp.cusId+", NAME: "+temp.cusName+", PRIORITY: "
                    +temp.priority+ "Age: "+temp.cusAge+", Gender: "+temp.cusGender+ "Type: "+temp.cusType);
            return temp;
        }
        return null;
        }

    public int countByType(String type) {
        int count=0;
        if(isEmpty())
        {
           return 0;
        }else{
            customer3 temp=start;
            while(temp!=null)
            {
                if(temp.cusType.equalsIgnoreCase(type))
                    count++;

                temp=temp.next;
            }
        }
        return count;
    }
    public int sumAgeByType(String type) {
        int sum=0;
        if(isEmpty())
        {
            return 0;
        }else
        {
            customer3 temp=start;
            while(temp!=null)
            {
                if(temp.cusType.equalsIgnoreCase(type))
                    sum+=temp.cusAge;
            }
        }
        return sum;
    }
    public void averageAgeByType(String type) {
        int avg=0;
        if(isEmpty())
        {
            return ;
        }else
        {
           avg=sumAgeByType(type)/countByType(type);
        }
        System.out.println("Average Age : "+avg);
    }
    public void changeType(int id, String type)
    {
        if(isEmpty())
        {
            System.out.println("No customer ");
        }else
        {
            customer3 temp=start;
            while(temp.cusId!=id)
            {
                temp=temp.next;
            }
            temp.cusType=type;
        }
    }
    public void changeGender(int id, String gender)
    {
        if(isEmpty())
        {
            System.out.println("No customer ");
        }else
        {
            customer3 temp=start;
            while(temp.cusId!=id)
            {
                temp=temp.next;
            }
            temp.cusGender=gender;
        }
    }
}
