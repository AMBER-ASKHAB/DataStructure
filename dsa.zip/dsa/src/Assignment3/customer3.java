package Assignment3;

public class customer3 {
     int cusId;
     String cusName;
     int cusAge;
     String cusGender;
     String cusType;
    customer3 next;
    int priority;

     customer3(int cusId,String cusName,int cusAge,String cusGender,String cusType) {
         this.cusId=cusId;
         this.cusName=cusName;
         this.cusAge=cusAge;
         this.cusGender=cusGender;
         this.cusType=cusType;
     }
}
