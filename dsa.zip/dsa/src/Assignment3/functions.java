package Assignment3;

import java.util.Scanner;

public class functions {
    Scanner sc=new Scanner(System.in);
    Queue q;
    functions()
    {
        System.out.println("WHICH DATA STRUCTURE YOU WANT TO USE ?");
        String ds=sc.next();
        if(ds.equalsIgnoreCase("Array"))
        {   q=new QueueArray3(30);}
        else if(ds.equalsIgnoreCase("LinkedList")){
            q=new QueueLL3();
        }
    }

    public void addCustomer()
    {

        System.out.println("Enter the Id of the customer");
        int id=sc.nextInt();
        System.out.println("Enter the Age of the customer");
        int age=sc.nextInt();
        System.out.println("Enter the name of the customer");
        String name=sc.next();
        System.out.println("Enter the gender of the customer");
        String gender=sc.next();
        System.out.println("Enter the Type of the customer");
        String type=sc.next();
        customer3 c= new customer3(id,name,age,gender,type);
        typeUpgradation(c);
        int p= getpriority(c);
        c.priority=p;
        q.enqueue(c);
    }
    public void serveCustomer()
    {
        q.dequeue();
    }
    public void displayYoungest()
    {
        q.displayYoungest();
    }
    public void displayEldest()
    {
        q.displayEldest();
    }
    public void displayAllVIIPs()
    {
        q.displayAllVIIPs();
    }
    public void femaleNormalCustomer()
    {
       q.displayFemaleNormal();
    }
    public void eldestVIIPCustomer()
    {
        q.displayEldestVVIP();
    }
    public void searchByName()
    {
        System.out.println("Enter the name of the customer");
        String name=sc.next();
        q.SearchByName(name);
    }
    public void DisplayAverageAge()
    {
        System.out.println("Enter the Type of the customer");
        String type=sc.next();
        q.averageAgeByType(type);
    }
    public void changeTypeOfCustomer()
    {
        System.out.println("Enter the Id of the customer");
        int id=sc.nextInt();
        System.out.println("Enter the Type of the customer");
        String type=sc.next();
       q.changeType(id,type);
    }
    public void changeGenderOfCustomer()
    {
        System.out.println("Enter the Id of the customer");
        int id=sc.nextInt();
        System.out.println("Enter the Gender of the customer");
        String type=sc.next();
        q.changeGender(id,type);
    }
    public void displayAverageAge()
    {
        System.out.println("Enter the Type of the customer");
        String type=sc.next();
        q.averageAgeByType(type);
    }

    public void display()
    {
        q.displayQueue();
    }
    public customer3 typeUpgradation(customer3 c)
    {
        if(c.cusGender.equalsIgnoreCase("Nmale"))
        {
            if(c.cusAge>60&&c.cusAge<70)
            {
                c.cusType="VIPmale";
            } else if (c.cusAge>70) {
                c.cusType="VVIPmale";
            }
        }else  if(c.cusGender.equalsIgnoreCase("Nfemale"))
        {
            if(c.cusAge>50&&c.cusAge<60)
            {
                c.cusType="VIPfemale";
            } else if (c.cusAge>60) {
                c.cusType="VVIPfemale";
            }
        }
        return c;
    }
    public int getpriority(customer3 c)
    {
        if(c.cusType.equalsIgnoreCase("Normal")&&c.cusGender.equalsIgnoreCase("male"))
            return 5;
        else if(c.cusType.equalsIgnoreCase("VIP") && c.cusGender.equalsIgnoreCase("male"))
            return 4;
        else if(c.cusType.equalsIgnoreCase("Normal") && c.cusGender.equalsIgnoreCase("female"))
            return 3;
        else if(c.cusType.equalsIgnoreCase("VIP") && c.cusGender.equalsIgnoreCase("Female"))
            return 2;
        else if(c.cusType.equalsIgnoreCase("VVIP") &&
                (c.cusGender.equalsIgnoreCase("Female")||
                 c.cusGender.equalsIgnoreCase("male")))
            return 1;
        else
            System.out.println("invalid Type Entered");

        return 0;
    }
}
