package Assignment3;

import java.util.Scanner;

public class main {
    static void main(String[] args) {
        functions f=new functions();
        Scanner sc=new Scanner(System.in);
        int choice;
        do {
            System.out.println("\n====== ABC Bank Customer Management ======");
            System.out.println("1. Add New Customer");
            System.out.println("2. Serve Customer (Remove from front)");
            System.out.println("3. Display All Customers");
            System.out.println("4. Display Youngest Customer");
            System.out.println("5. Display Eldest Male Customer");
            System.out.println("6. Display All VVIP Customers");
            System.out.println("7. Display Normal Female Customers");
            System.out.println("8. Display Eldest VIP Customer");
            System.out.println("9. Search Customer by Name");
            System.out.println("10. Display Average Age of VVIP Customers");
            System.out.println("11. Change Customer Type");
            System.out.println("12. Change Customer Gender");
            System.out.println("13. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch(choice) {
                case 1:
                    f.addCustomer();
                    break;
                case 2:
                    f.serveCustomer();
                    break;
                case 3:
                    f.display();
                    break;
                case 4:
                   f.displayYoungest();
                    break;
                case 5:
                   f.displayEldest();
                    break;
                case 6:
                   f.displayAllVIIPs();
                    break;
                case 7:
                   f.femaleNormalCustomer();
                    break;
                case 8:
                   f.eldestVIIPCustomer();
                    break;
                case 9:
                    f.searchByName();
                    break;
                case 10:
                    f.displayAverageAge();
                    break;
                case 11:
                    f.changeTypeOfCustomer();
                    break;
                case 12:
                   f.changeGenderOfCustomer();
                    break;
                case 13:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid Choice! Try again.");
            }

        } while(choice != 13);

    }
}
