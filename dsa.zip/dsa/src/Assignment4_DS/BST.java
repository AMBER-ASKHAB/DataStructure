package Assignment4_DS;

public class BST {

    node root;

    public void add(node n) {
        if (root == null) {
            root = n;
            return;
        }

        node temp = root;
        while (true) {
            if (n.num < temp.num) {
                if (temp.left == null) {
                    temp.left = n;
                    break;
                } else
                    temp = temp.left;
            } else {
                if (temp.right == null) {
                    temp.right = n;
                    break;
                } else
                    temp = temp.right;
            }
        }
    }

    public void display() {
        displaynodes(root);
        System.out.println();
    }

    public void displaynodes(node n) {
        if (n == null) return;
        displaynodes(n.left);
        System.out.print(n.num + " ");
        displaynodes(n.right);
    }

    public void delete(int num) {

        node curr = root;
        node parent = null;

        while (curr != null && curr.num != num) {
            parent = curr;
            if (num < curr.num)
                curr = curr.left;
            else
                curr = curr.right;
        }

        if (curr == null) {
            System.out.println("Node not found");
            return;
        }

        if (curr.left == null && curr.right == null) {

            if (curr == root)
                root = null;
            else if (parent.left == curr)
                parent.left = null;
            else
                parent.right = null;
        }

        else if (curr.left == null || curr.right == null) {

            node child = (curr.left != null) ? curr.left : curr.right;

            if (curr == root)
                root = child;
            else if (parent.left == curr)
                parent.left = child;
            else
                parent.right = child;
        }

        else {
            node succParent = curr;
            node succ = curr.right;
            while (succ.left != null) {
                succParent = succ;
                succ = succ.left;
            }

            curr.num = succ.num;

            if (succParent.left == succ)
                succParent.left = succ.right;
            else
                succParent.right = succ.right;
        }
    }

    public void clear() {
        root = null;
    }
}
