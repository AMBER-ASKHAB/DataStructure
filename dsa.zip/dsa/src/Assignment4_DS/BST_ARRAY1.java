package Assignment4_DS;

public class BST_ARRAY1 {
    node[] arr = new node[1000];
    int c = 0;
    BST_ARRAY1() {
        for (int i = 0; i < 1000; i++) {
            arr[i] = new node();
        }
    }
    public void Add(node n) {
        if(arr[0].num==-1)
        {
            arr[0]=n;
            c++;
            return;
        }else
        {
            int i=0;
            while(i<arr.length)
            {
                if(arr[i].num>n.num){
                    if(arr[i].l==-1)
                    {
                        arr[i].l=c;
                        arr[c]=n;
                        c++;
                        return;
                    }else {
                        i=arr[i].l;
                    }
                }else
                {
                    if(arr[i].num<n.num){
                        if(arr[i].r==-1)
                        {
                            arr[i].r=c;
                            arr[c]=n;
                            c++;
                            return;
                        }else {
                            i=arr[i].r;
                        }
                    }
                }
            }
        }
    }
    public void display()
    {
        display(0);
    }
    public void display(int n) {
        if(n==-1)
            return;
        display(arr[n].l);
        System.out.println(arr[n].num);
        display(arr[n].r);
    }
    public void delete(int n) {
        int i=0;
        node curr = null;
        node prev = null;
        if(arr[0].num==n)
        {
            curr=arr[0];
            return;
        }else {
            while(i<arr.length)
            {
                if(arr[i].num==n)
                {
                    curr=arr[i];
                    break;
                }else
                {
                    prev = arr[i];
                    if(n<arr[i].num)
                    {
                        i=arr[i].l;
                    }else {
                        i=arr[i].r;
                    }
                }
            }
        }

        if(curr.l==-1 && curr.r==-1)
        {
            if(curr.num<prev.num)
            {
                prev.l=-1;
            }else
            {
                prev.r=-1;
            }
        }
        else if(curr.l==-1 || curr.r==-1)
        {

            if(curr.num<prev.num)
            {
                if(curr.l==-1)
                   prev.l=curr.r;
                else
                    prev.l=curr.l;
            }else
            {
                if(curr.l==-1)
                    prev.r=curr.r;
                else
                    prev.r=curr.l;
            }

        }else
        {
            node succparent=curr;
            node succ=curr.right;

            while(succ.l!=-1)
            {
                succparent=succ;
                succ=arr[succ.l];
            }
            curr.num=succ.num;
            if(arr[succparent.l]== succ)
            {
                succparent.l=succ.r;
            }else if(arr[succparent.r]== succ)
            {
                succparent.r=succ.r;
            }
        }
    }
}
