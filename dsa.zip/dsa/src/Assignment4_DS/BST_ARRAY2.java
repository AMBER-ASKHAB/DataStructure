package Assignment4_DS;

public class BST_ARRAY2 {
    node[] arr= new node[100];
    int c=0;
    BST_ARRAY2(){
        for(int i=0;i<100;i++)
            {
            arr[i]=new node();
            }
    }
    public void add(node n){
        if(arr[0].num==-1){
            arr[0]=n;
            c++;
            return;
        }else
        {
            int i=0;
            while(i<arr.length)
            {
                if(arr[i].num==-1)
                {
                    arr[i]=n;
                    return;
                }
                else {
                    if(n.num< arr[i].num)
                    {
                        i=i*2+1;
                    }else
                    {
                        i=i*2+2;
                    }
                }

            }
        }

    }
    public void display()
    {
        display(0);
    }
    public void display(int n){
        if(arr[n].num==-1)
            return;
        display(n*2+1);
        System.out.println(arr[n].num);
        display(n*2+2);

    }
    public void delete(int key)
    {
        int i = 0;

        while(i < arr.length && arr[i].num != -1)
        {
            if(arr[i].num == key)
                break;

            if(key < arr[i].num)
                i = i*2 + 1;
            else
                i = i*2 + 2;
        }

        if(i >= arr.length || arr[i].num == -1)
            return;

        int left = 2*i + 1;
        int right = 2*i + 2;

        if((left >= arr.length || arr[left].num == -1) &&
                (right >= arr.length || arr[right].num == -1))
        {
            arr[i] = new node();
            return;
        }

        if(left < arr.length && arr[left].num != -1 && (right >= arr.length || arr[right].num == -1))
        {
            arr[i].num = arr[left].num;
            arr[left] = new node();
            return;
        }

        if(right < arr.length && arr[right].num != -1 && (left >= arr.length || arr[left].num == -1))
        {
            arr[i].num = arr[right].num;
            arr[right] = new node();
            return;
        }

        int succ = right;
        while(2*succ + 1 < arr.length && arr[2*succ + 1].num != -1)
        {
            succ = 2*succ + 1;
        }

        arr[i].num = arr[succ].num;
        arr[succ] = new node();
    }



}
