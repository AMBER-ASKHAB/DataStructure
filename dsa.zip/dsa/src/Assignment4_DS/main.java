package Assignment4_DS;

import java.util.Scanner;

public class main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        BST bst = new BST();
        //BST_ARRAY1 bst = new BST_ARRAY1();
        //BST_ARRAY2 bst = new BST_ARRAY2();

        int choice;

        do {
            System.out.println("\n------ BST MENU ------");
            System.out.println("1. Add node");
            System.out.println("2. Delete node");
            System.out.println("3. Display tree");
            System.out.println("4. Clear tree");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    int[] arr = {50, 30, 70, 20, 40, 60, 80, 65};
                    for (int x : arr)
                        bst.add(new node(x));
                    System.out.println("Default nodes inserted.");
                    break;

                case 2:
                    System.out.print("Enter value to delete: ");
                    int key = sc.nextInt();
                   // bst.delete(key);
                    break;

                case 3:
                    System.out.print("Inorder Traversal: ");
                    bst.display();
                    break;

                case 4:
                   // bst.clear();
                    System.out.println("Tree cleared.");
                    break;

                case 5:
                    System.out.println("Exiting program...");
                    return;

                default:
                    System.out.println("Invalid choice!");
            }

        } while (true);
    }
}
