package Assignment4_DS;

public class node {
    int num;
    node left;
    node right;
    int l;
    int r;
    node()
    {
        num = -1;
        l=r=-1;
        left=null;
        right=null;

    }
    node(int num) {
        this.num = num;
        l=r=-1;
    }
}
