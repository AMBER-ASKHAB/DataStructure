package Assignment5_DS;

import java.util.*;

public class AVL {

    node root;

    int height(node n) {
        if(n==null)return 0;
        else return n.height;
    }

    int max(int a, int b) {
        if(a>b)return a;
        else return b;
    }

    int balance(node n) {
        if(n==null)return 0;
        else return  height(n.left) - height(n.right);

    }

    node rightRotate(node y) {
        node x = y.left;
        node t2 = x.right;
        x.right = y;
        y.left = t2;
        y.height = max(height(y.left), height(y.right)) + 1;
        x.height = max(height(x.left), height(x.right)) + 1;

        return x;
    }

    node leftRotate(node x) {
        node y = x.right;
        node t2 = y.left;
        y.left = x;
        x.right = t2;

        x.height = max(height(x.left), height(x.right)) + 1;
        y.height = max(height(y.left), height(y.right)) + 1;

        return y;
    }

    public void add(int key) {
        if (root == null) {
            root = new node(key);
            return;
        }

        node current = root;
        node parent = null;

        Stack<node> path = new Stack<>();
        while (current != null) {
            parent = current;
            path.push(current);
            if (key < current.num)
                current = current.left;
            else if (key > current.num)
                current = current.right;
            else
                return;
        }

        node newNode = new node(key);
        if (key < parent.num)
            parent.left = newNode;
        else
            parent.right = newNode;

        node child;
        while (!path.isEmpty()) {
            node n = path.pop();
            n.height = 1 + max(height(n.left), height(n.right));

            int bal = balance(n);

            // LL
            if (bal > 1 && key < n.left.num) {
                if (!path.isEmpty()) {
                    node p = path.peek();
                    if (p.left == n) p.left = rightRotate(n);
                    else p.right = rightRotate(n);
                } else {
                    root = rightRotate(n);
                }
            }
            // LR
            if (bal > 1 && key > n.left.num) {
                n.left = leftRotate(n.left);
                if (!path.isEmpty()) {
                    node p = path.peek();
                    if (p.left == n) p.left = rightRotate(n);
                    else p.right = rightRotate(n);
                } else {
                    root = rightRotate(n);
                }
            }
            // RR
            if (bal < -1 && key > n.right.num) {
                if (!path.isEmpty()) {
                    node p = path.peek();
                    if (p.left == n) p.left = leftRotate(n);
                    else p.right = leftRotate(n);
                } else {
                    root = leftRotate(n);
                }
            }

            // RL
            if (bal < -1 && key < n.right.num) {
                n.right = rightRotate(n.right);
                if (!path.isEmpty()) {
                    node p = path.peek();
                    if (p.left == n) p.left = leftRotate(n);
                    else p.right = leftRotate(n);
                } else {
                    root = leftRotate(n);
                }
            }
        }
    }
    public void display() {
        inorder(root);
        System.out.println();
    }

    private void inorder(node n) {
        if (n == null)
            return;

        inorder(n.left);
        System.out.print(n.num + " ");
        inorder(n.right);
    }

   /* public void display() {
        Stack<node> stack = new Stack<>();
        node current = root;
        while (current != null || !stack.isEmpty()) {
            while (current != null) {
                stack.push(current);
                current = current.left;
            }
            current = stack.pop();
            System.out.print(current.num + " ");
            current = current.right;
        }
        System.out.println();
    }*/
}
