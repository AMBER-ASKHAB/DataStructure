package Assignment5_DS;

public class node {
    int num;
    int height;
    node left, right;

    node(int num) {
        this.num = num;
        height = 1;
        left = right = null;
    }
}
