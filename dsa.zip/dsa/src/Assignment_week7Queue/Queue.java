package Assignment_week7Queue;

public class Queue {
    complaint[] C = new complaint[3];
    int count = 0;
    int flag = 0;
    int d = 0;
    int c = 0;

    Queue() {
        for (int i = 0; i < 3; i++) {
            C[i] = new complaint();
        }
    }

    public void enqueue(complaint obj) {
        if (c == d && flag == 1) {
            System.out.println("Queue is full! You can't insert ID = " + obj.complaintId);
            return;
        }

        C[c] = obj;
        count++;

        if (c == C.length - 1) {
            c = 0;
            flag = 1;
        } else {
            c++;
        }
    }

    public complaint dequeue() {
        if (c == d && flag == 0) {
            System.out.println("No complaints to process! Queue is empty.");
            return null;
        }

        complaint temp = C[d];
        count--;

        if (d == C.length - 1) {
            d = 0;
            flag = 0;
        } else {
            d++;
        }

        System.out.println("Complaint Processed: [" + temp.complaintId + ", " +
                temp.customertName + ", " + temp.complaintType + "]");
        return temp;
    }

    public void display() {
        if (c == d && flag == 0) {
            System.out.println("All complaints have been resolved.");
            return;
        }

        System.out.println("Remaining Complaints:");

        if (c == d && flag == 1) { // queue full
            for (int i = 0; i < C.length; i++) {
                printComplaint(C[i]);
            }
        } else if (c < d && flag == 1) {
            for (int i = d; i < C.length; i++) {
                printComplaint(C[i]);
            }
            for (int i = 0; i < c; i++) {
                printComplaint(C[i]);
            }
        } else if (c > d && flag == 0) {
            for (int i = d; i < c; i++) {
                printComplaint(C[i]);
            }
        }
    }

    private void printComplaint(complaint comp) {
        System.out.println("[" + comp.complaintId + ", " +
                comp.customertName + ", " + comp.complaintType + "]");
    }
}
