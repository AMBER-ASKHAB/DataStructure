package Assignment_week7Queue;

public class complaint {
    int complaintId;
    String customertName;
    String complaintType;

    complaint() {}

    complaint(int complaintId, String customertName, String complaintType) {
        this.complaintId = complaintId;
        this.customertName = customertName;
        this.complaintType = complaintType;
    }
}
