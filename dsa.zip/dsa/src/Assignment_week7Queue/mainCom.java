package Assignment_week7Queue;

import java.util.Scanner;

public class mainCom {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Queue Q = new Queue();
        int choice;

        do {
            System.out.println("\n--- PakConnect Complaint Management System ---");
            System.out.println("1. Add Complaint");
            System.out.println("2. Process Complaint");
            System.out.println("3. Display Remaining Complaints");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Complaint ID: ");
                    int id = sc.nextInt();
                    System.out.print("Enter Customer Name: ");
                    String name = sc.next();
                    System.out.print("Enter Complaint Type: ");
                    sc.nextLine();
                    String type = sc.nextLine();
                    complaint c = new complaint(id, name, type);
                    Q.enqueue(c);
                    break;

                case 2:
                    Q.dequeue();
                    break;

                case 3:
                    Q.display();
                    break;

                case 4:
                    System.out.println("Exiting... Thank you!");
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 4);
    }
}
