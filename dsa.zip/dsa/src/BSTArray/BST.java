package BSTArray;

public class BST {
    student[] arr=new student[100];
    BST()
    {
        for(int i=0;i<100;i++)
        {
            arr[i]=new student();
        }
    }
    int c=0;
    void addnode(int x)
    {
        int i=0;
        while(i<arr.length)
        {
            if(arr[0].age==-1)
            {
                arr[0].age=x;break;
            }else
            {
                if(arr[c].age==-1)
                {
                    if(arr[c].age<arr[i].age)
                    {
                        if(arr[i].l==-1)
                        {
                            arr[i].l=c;
                            arr[c].age=x;
                            c++;
                        }else
                            i=arr[i].l;
                    }
                }else {
                        if(arr[i].r==-1)
                        {
                            arr[i].r=c;
                            arr[c].age=x;
                            c++;
                        }else
                            i=arr[i].l;
                }
            }
        }

    }
}
