package BSTArray;

public class MAIN {
    static void main() {
        BST b=new BST();
        b.addnode(60);
        b.addnode(40);
        b.addnode(15);
    }


}
