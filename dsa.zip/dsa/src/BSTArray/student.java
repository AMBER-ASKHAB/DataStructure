package BSTArray;

public class student {
    int age;
    int r;
    int l;
    student()
    {
        this.age=-1;
        this.r=-1;
        this.l=-1;
    }
    student(int n) {
        this.age=n;
        this.r=-1;
        this.l=-1;
    }
}
