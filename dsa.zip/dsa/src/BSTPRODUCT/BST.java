package BSTPRODUCT;

public class BST {
    int c = 0;

    BST() {
    }

    void addnode(product x, product[] arr) {
        if (c == 0) {
            arr[c] = x;
            c++;
            return;
        }

        int i = 0;

        while (true) {

            if (x.pqty > arr[i].pqty) {

                if (arr[i].r == -1) {
                    arr[i].r = c;
                    arr[c] = x;
                    c++;
                    return;
                }

                i = arr[i].r;
            }

            else {

                if (arr[i].l == -1) {
                    arr[i].l = c;
                    arr[c] = x;
                    c++;
                    return;
                }

                i = arr[i].l;
            }
        }
    }

    void displayd(product x, product[] arr) {
        if (x == null) return;
        if (x.pqty == -1) return;

        if (x.r != -1) displayd(arr[x.r], arr);
        System.out.println(x.pqty);
        if (x.l != -1) displayd(arr[x.l], arr);
    }
    void displayA(product x, product[] arr) {
        if (x == null) return;
        if (x.pqty == -1) return;

        if (x.l != -1) displayA(arr[x.l], arr);
        System.out.println(x.pqty);
        if (x.r != -1) displayA(arr[x.r], arr);
    }
    void max(product[] arr) {
        if (arr[0].pqty == -1) return;
        int i = 0;
        while (arr[i].r != -1) {
            i = arr[i].r;
        }
        System.out.println(arr[i].pqty);
    }

    void displayqty(int qty, product[] arr) {
        int i = 0;

        while (i != -1) {
            if (arr[i].pqty == qty) {
                System.out.println("found the quantity"+arr[i].pqty);
                return;
            }

            if (qty > arr[i].pqty) {
                i = arr[i].r;
            } else {
                i = arr[i].l;
            }
        }
    }


}
