package BSTPRODUCT;

public class main {

    static product[] arr = new product[100];

    static void main() {
        for (int i = 0; i < 100; i++) {
            arr[i] = new product();
        }

        BST obj = new BST();

        product p = new product(50);
        product p1 = new product(30);
        product p2 = new product(70);

        obj.addnode(p, arr);
        obj.addnode(p1, arr);
        obj.addnode(p2, arr);

        obj.displayd(arr[0], arr);
        obj.displayA(arr[0], arr);
        obj.max( arr);
        obj.displayqty(50,arr);
    }
}
