package BSTPRODUCT;

public class product {
    int pid, price, pqty;
    String desc;
    int r;
    int l;

    product() {
        this.pqty = -1;
        this.r = -1;
        this.l = -1;
    }

    public product(int pqty) {
        this.pqty = pqty;
        this.r = -1;
        this.l = -1;
    }
}
