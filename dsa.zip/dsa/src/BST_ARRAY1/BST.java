package BST_ARRAY1;

public class BST {
    patient[] arr = new patient[1000];
    int c = 0;

    BST() {
        for (int i = 0; i < arr.length; i++)
            arr[i] = new patient();
    }

    void addpatient(patient x) {
        if (arr[0].mrn == -1) {
            arr[0] = x;
            c = 1;
            return;
        }
        int i = 0;
        while (i < arr.length) {
            if (x.mrn < arr[i].mrn) {
                if (arr[i].l == -1) {
                    arr[i].l = c;
                    arr[c] = x;
                    c++;
                    break;
                } else
                    i = arr[i].l;
            } else {
                if (arr[i].r == -1) {
                    arr[i].r = c;
                    arr[c] = x;
                    c++;
                    break;
                } else
                    i = arr[i].r;
            }
        }
    }

    void searchbymrn(int mrn) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].mrn == mrn) {
                System.out.println(arr[i].name + arr[i].condition + arr[i].mrn);
            }
        }
    }

    void displayviaCondition(String condition) {
        for (int j = 0; j < arr.length; j++) {
            if (arr[j].condition.equalsIgnoreCase(condition)) {
                System.out.println(arr[j].name + arr[j].condition + arr[j].mrn);
            }
        }
    }
}
