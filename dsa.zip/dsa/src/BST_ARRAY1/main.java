package BST_ARRAY1;
import java.util.Scanner;

public class main {
    static void main(String[] args) {
        BST bst=new BST();
        Scanner sc = new Scanner(System.in);
        do{
            System.out.println("1.Add Patient :");
            System.out.println("2.Search Patient by MRN :");
            System.out.println("3.LIST PATIENT WITH SAME MEDICAL CONDITION :");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter MRN:");
                    int mrn = sc.nextInt();
                    System.out.println("Enter Name:");
                    String name = sc.next();
                    System.out.println("Enter Condition:");
                    String medical_cond = sc.next();
                    patient p = new patient(mrn, name, medical_cond);
                    bst.addpatient(p);
                    break;

                case 2:
                    System.out.println("Enter MRN:");
                    int mr = sc.nextInt();
                    bst.searchbymrn(mr);
                    break;

                case 3:
                    System.out.println("Medical condition");
                    String condition = sc.next();
                    bst.displayviaCondition(condition);
            }}while (true);

    }
}
