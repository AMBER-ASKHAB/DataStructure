package BST_ARRAY1;

public class patient {
    int mrn;
    String name;
    String condition;
    int l;
    int r;
    patient(int mrn, String name, String condition) {
        this.mrn = mrn;
        this.name = name;
        this.condition = condition;
        l=-1;
        r=-1;
    }
    patient()
    {
        this.mrn = -1;

        l=-1;
        r=-1;
    }
}
