package BST_LINKEDLIST1;

import BST_linkedlist.node;

public class BST {
    patient root;

    public void addNode(patient x) {
        if (root == null) {
            root = x;
        } else {
            patient t = root;
            while (true) {
                if (x.mrn < t.mrn) {
                    if (t.left == null) {
                        t.left = x;
                        break;
                    } else
                        t = t.left;
                } else {
                    if (t.right == null) {
                        t.right = x;
                        break;
                    } else
                        t = t.right;
                }
            }
        }
    }

    public int search(int num) {
        patient t = root;
        if (t == null)
            return 0;
        while (true) {
            if (t.mrn == num) {
                System.out.println("found");
                return t.mrn;
            } else {
                if (num < t.mrn) {
                    t = t.left;
                } else {
                    t = t.right;
                }
            }
        }
    }


    void patient_sameCond(String condition) {
        sameCondHelper(root, condition);
    }

    private void sameCondHelper(patient node, String condition) {
        if (node == null)
            return;
        sameCondHelper(node.left, condition);
        if (node.condition.equalsIgnoreCase(condition)) {
            System.out.println(node.mrn + " " + node.name + " " + node.condition);
        }
        sameCondHelper(node.right, condition);
    }

    void sorted() {
        sortedhelper(root);
    }

    void sortedhelper(patient node) {
        if (node == null)
            return;
        sortedhelper(node.left);
        System.out.println(node.mrn + " " + node.name + " " + node.condition);
        sortedhelper(node.right);
    }
    void patientmin()
    {
        patientmin(root);
    }
    void patientmin(patient node) {
        if (node == null)
            System.out.println("NO PATIENT MIN");
        else
        {
            if(node.left == null)
            {
                System.out.println(node.mrn + " " + node.name + " " + node.condition);
            }else
                {
                patientmin(node.left);
                }
        }
    }
    void patientmax()
    {
        patientmax(root);
    }
    void patientmax(patient node) {
        if (node == null)
            System.out.println("NO PATIENT MIN");
        else
        {
            if(node.right == null)
            {
                System.out.println(node.mrn + " " + node.name + " " + node.condition);
            }else
            {
                patientmin(node.right);
            }
        }
    }
int count()
{
    return count(root);
}
int  count(patient node)
{
    if(node == null)
        return 0;
   else{
       return 1+count(node.left)+count(node.right);
    }
}

    void delbymrn(int mrn) {
        root = delete(root, mrn);
    }

    patient delete(patient node, int mrn) {
        if (node == null)
            return null;

        if (mrn < node.mrn)
            node.left = delete(node.left, mrn);
        else if (mrn > node.mrn)
            node.right = delete(node.right, mrn);
        else {
            if (node.left == null && node.right == null)
                return null;
            else if (node.left == null)
                return node.right;
            else if (node.right == null)
                return node.left;
            else {
                patient t = minNode(node.right);
                node.mrn = t.mrn;
                node.name = t.name;
                node.condition = t.condition;
                node.right = delete(node.right, t.mrn);
            }
        }
        return node;
    }

    patient minNode(patient node) {
        while (node.left != null)
            node = node.left;
        return node;
    }

}