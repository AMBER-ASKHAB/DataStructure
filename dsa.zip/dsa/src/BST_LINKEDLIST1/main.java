package BST_LINKEDLIST1;

import java.util.Scanner;

public class main {
    static void main(String[] args) {
        BST bst=new BST();
        Scanner sc = new Scanner(System.in);
        do{
        System.out.println("1.Add Patient :");
        System.out.println("2.Search Patient by MRN :");
        System.out.println("3.LIST PATIENT WITH SAME MEDICAL RECORD :");
        System.out.println("4.SORTED MEDICAL RECORD");
            System.out.println("5.MINIMUM MEDICAL RECORD");
            System.out.println("6.MaxiMUM MEDICAL RECORD");
            System.out.println("7.count");
            System.out.println("7.Delete by mrn");
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Enter MRN:");
                int mrn = sc.nextInt();
                System.out.println("Enter Name:");
                String name = sc.next();
                System.out.println("Enter Condition:");
                String medical_cond = sc.next();
                patient p = new patient(mrn, name, medical_cond);
                bst.addNode(p);
                break;

                case 2:
                    System.out.println("Enter MRN:");
                    int mr = sc.nextInt();
                    bst.search(mr);
                    break;

                    case 3:
                        System.out.println("Medical condition");
                        String condition = sc.next();
                        bst.patient_sameCond(condition);
                        break;

                        case 4:
                            System.out.println("SORTED MEDICAL RECORD");
                            bst.sorted();
                            break;

                            case 5:
                                System.out.println("MINIMUM MEDICAL RECORD");
                                bst.patientmin();
                                break;
                                case 6:
                                    System.out.println("MAXIMUM MEDICAL RECORD");
                                    bst.patientmax();
                                    break;

                                    case 7:
                                        System.out.println("Count = "+bst.count());
                                        break;



        }}while (true);

    }
}
