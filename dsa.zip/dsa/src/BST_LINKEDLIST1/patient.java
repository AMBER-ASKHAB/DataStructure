package BST_LINKEDLIST1;

public class patient {
    int mrn;
    String name;
    String condition;
    patient left;
    patient right;
    patient(int mrn, String name, String condition)
    {
        this.mrn=mrn;
        this.name = name;
        this.condition = condition;
    }
}
