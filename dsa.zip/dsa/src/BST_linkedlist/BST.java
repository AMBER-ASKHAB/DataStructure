package BST_linkedlist;

public class BST {
    node root;
    public void addNode(node x)
    {
        if(root==null)
        {
            root=x;
        }else
        {
            node t=root;
            while(true)
            {
                if(x.num<t.num)
                {
                    if(t.left==null)
                     {
                        t.left=x;
                        break;
                     }else
                         t=t.left;
                }else
                {
                    if(t.right==null)
                    {
                        t.right=x;
                        break;
                    }else
                        t=t.right;
                }
            }
        }
    }


    public void display()
    {
        if(root==null)
        {
            System.out.println("Empty Tree");
        }else
        {
            node t=root;
            solve(t);
        }
    }
    public int search(int num)
    {
        node t=root;
        if(t==null)
            return 0;
        while(true)
        {
            if(t.num==num)
            {
                return t.num;
            }else
            {
                if(num<t.num)
                {
                   t=t.left;
                }else
                {
                    t=t.right;
                }
            }
        }
    }
    public void solve(node n)
    {
        if(n==null)
            return;
        else
        {
            solve(n.left);
            System.out.println("number "+n.num);
            solve(n.right);
        }

    }
}
