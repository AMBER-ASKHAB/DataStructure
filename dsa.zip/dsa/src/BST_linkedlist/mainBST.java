package BST_linkedlist;

public class mainBST {
        public static void main(String[] args) {
            BST tree = new BST();


            node n1 = new node(50);
            node n2 = new node(30);
            node n3 = new node(70);
            node n4 = new node(20);
            node n5 = new node(40);
            node n6 = new node(60);
            node n7 = new node(80);


            tree.addNode(n1);
            tree.addNode(n2);
            tree.addNode(n3);


            System.out.println("In-order traversal of BST:");
            tree.display();

            int numToSearch = 40;
            int result = tree.search(numToSearch);

            if (result == numToSearch)
                System.out.println("\nNumber " + numToSearch + " found in BST.");
            else
                System.out.println("\nNumber " + numToSearch + " not found in BST.");
        }


}
