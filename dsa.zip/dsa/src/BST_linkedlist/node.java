package BST_linkedlist;

public class node {
    int num;
    node left;
    node right;
    node(int n){
        num=n;
    }
}
