package DS_task3_11;

public class TrafficSignalSystem {
    String[] directions = new String[4];
    int count = 0;
    int flag = 0;
    int d = 0;
    int c = 0;

    public TrafficSignalSystem() {
        directions[0] = "North";
        directions[1] = "East";
        directions[2] = "South";
        directions[3] = "West";
        count = 4;
        c = 4;
    }

    public void enqueue(String direction) {
        if (c == d && flag == 1) {
            System.out.println("Queue is full! Cannot insert " + direction);
            return;
        }

        directions[c % directions.length] = direction;
        count++;
        System.out.println("Inserted " + direction + " at index " + c);

        if (c == directions.length - 1) {
            c = 0;
            flag = 1;
        } else {
            c++;
        }

        System.out.println("c=" + c + ", d=" + d + ", flag=" + flag + ", count=" + count);
    }

    public String dequeue() {
        if (c == d && flag == 0) {
            System.out.println("Queue is empty!");
            return null;
        }

        String temp = directions[d];
        System.out.println("Signal turned green for: " + temp);
        count--;

        if (d == directions.length - 1) {
            d = 0;
            flag = 0;
        } else {
            d++;
        }

        System.out.println("c=" + c + ", d=" + d + ", flag=" + flag + ", count=" + count);
        return temp;
    }

    public void displayQueue() {
        if (c == d && flag == 0) {
            System.out.println("Queue is empty.");
            return;
        }

        System.out.println("Current Queue of Directions:");

        if (c == d && flag == 1) {
            for (int i = 0; i < directions.length; i++) {
                System.out.print(directions[i] + " ");
            }
        } else if (c < d && flag == 1) {
            for (int i = d; i < directions.length; i++) {
                System.out.print(directions[i] + " ");
            }
            for (int i = 0; i < c; i++) {
                System.out.print(directions[i] + " ");
            }
        } else if (c > d && flag == 0) {
            for (int i = d; i < c; i++) {
                System.out.print(directions[i] + " ");
            }
        }

        System.out.println();
    }

    public void currentSignal() {
        if (c == d && flag == 0) {
            System.out.println("No signal is green.");
        } else {
            System.out.println("Current green signal: " + directions[d]);
        }
    }
}
