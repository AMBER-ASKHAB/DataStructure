package DS_task3_11;

public class directions {
    String direction;
    int time=2;
}
