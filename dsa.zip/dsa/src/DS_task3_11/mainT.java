package DS_task3_11;

public class mainT {
    public static void main(String[] args) {
        TrafficSignalSystem signal = new TrafficSignalSystem();

        signal.displayQueue();
        signal.currentSignal();

        for (int i = 0; i < 8; i++) {
            System.out.println("\nCycle " + (i + 1) + ":");
            signal.currentSignal();
            String green = signal.dequeue();
            signal.enqueue(green);
        }
    }
}
