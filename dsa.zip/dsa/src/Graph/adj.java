package Graph;

public class adj {
    String id;
    double weight;
    adj uNext;

}
