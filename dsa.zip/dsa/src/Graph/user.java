package Graph;

public class user {
    String name,id;
    user uNext;
    adj astart;
}
