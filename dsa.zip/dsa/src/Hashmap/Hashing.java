package Hashmap;

public class Hashing {
    student[] arr= new student[20];
    int hashfunction(String name)
    {
        int i=0; int hv=0;
        while(i<name.length())
        {
            hv+=name.charAt(i);
            i=i+1;
        }
        return hv%arr.length;
    }
    void insert(student s)
    {
        Boolean inserted = false;
        int index=hashfunction(s.name);
        if(arr[index]==null)
        {
            arr[index]=s;
            inserted = true;
            return;
        }

        else
        {
            System.out.println("collision happened");
            for(int i=index;i<arr.length;i++)
            {
                if(arr[i]==null)
                {
                    arr[i]=s;
                    inserted = true;
                    return;
                }
            }
            if(inserted==false)
            {
                for(int i=0;i<index;i++)
                {
                    arr[i]=s;
                    return;
                }
            }
        }

        if(inserted==true)
        {
            System.out.println("Student "+s.name+" has been inserted");
        }
    }

    void search(String name)
    {
        Boolean found = false;
        int index=hashfunction(name);
        if(arr[index]==null)
            System.out.println("Student "+name+" has'nt been found");
        else {
            if(arr[index].name.equals(name))
            {
                System.out.println("Student "+name+" has been found");
                found=true;
                return;
            }else
            {
                for(int i=index;i< arr.length;i++)
                {
                    if(arr[i].name.equals(name))
                    {
                        System.out.println("Student "+name+" has been found");
                        found=true;
                        return;
                    }
                }
                if(found==false)
                {
                    for(int i=0;i<index;i++)
                    {
                        if(arr[i].name.equals(name))
                            {
                            System.out.println("Student "+name+" has been found");
                            found=true;
                            return;
                            }
                    }
                }
            }
        }
      if(found==false)
      {
          System.out.println("Student "+name+" has'nt  been found");
      }
    }
    void probingAdd(student s, int index )
    {

    }
}
