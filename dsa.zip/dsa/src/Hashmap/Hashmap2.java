package Hashmap;

public class Hashmap2 {
    student[] arr=new student[100];
    Hashmap2(){
        for(int i=0;i<100;i++)
        {
            arr[i]=new student();
        }
    }

    int hashfunction(String name)
    {
        int i=0; int hv=0;
        while(i<name.length())
        {
            hv+=name.charAt(i);
            i=i+1;
        }
        return hv%arr.length;
    }
    void insert(student s)
    {
        int hv=hashfunction(s.name);
        if(arr[hv].name==null)
        {
            arr[hv]=s;
            return;
        }else
        {
            System.out.println("COLLISION HAPPENED ... !");
            s.next=arr[hv].next;
            arr[hv].next=s;
        }
    }
    boolean search(String s)
    {
        int hv=hashfunction(s);
        if(arr[hv].name.equals(s))
        {
            return true;
        }else
        {
            student t=arr[hv].next;
            while(t.next!=null)
            {
                if(t.name.equals(s))
                {
                    return true;
                }
                t=t.next;
            }
        }
        return false;
    }

}
