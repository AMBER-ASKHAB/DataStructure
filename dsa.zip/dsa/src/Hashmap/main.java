package Hashmap;

import java.util.Scanner;

public class main {


    static void main(String[] args) {
        //Hashing h=new Hashing();
        Hashmap2 h=new Hashmap2();
        int choice=0;
        do {
            System.out.println("1, Add student");
            System.out.println("2, Search student");
            Scanner sc = new Scanner(System.in);
            choice = sc.nextInt();
            switch (choice) {
                case 1:

                    System.out.println("Enter student ID");
                    int id = sc.nextInt();
                    System.out.println("Enter student name");
                    String name = sc.next();
                    System.out.println("Enter student age");
                    int age = sc.nextInt();
                    h.insert(new student(id, name, age));

                    break;
                case 2:
                    System.out.println("Enter student Name");
                    String name1 = sc.next();
                    h.search(name1);
                    break;
                default:
                    System.out.println("Wrong choice");
            }
        }while(choice<=2);
    }
}
