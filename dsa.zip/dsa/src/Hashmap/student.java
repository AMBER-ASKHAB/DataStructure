package Hashmap;

public class student {
    int sid;
    String name;
    int age;
    student next;
    student()
    {

    }
    student(int sid,String name,int age)
    {
        this.sid=sid;
        this.name=name;
        this.age=age;
    }
}
