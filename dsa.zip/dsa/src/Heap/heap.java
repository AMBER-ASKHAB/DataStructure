package Heap;

import java.util.Scanner;

public class heap {

    student[] arr = new student[6];
    Scanner cin = new Scanner(System.in);

    public heap() {
        for (int i = 0; i < arr.length; i++)
            arr[i] = new student();
    }

    void takeInput() {
        System.out.println("Enter ages of 6 students:");
        for (int i = 0; i < arr.length; i++) {
            System.out.print("Age " + (i + 1) + ": ");
            arr[i].age = cin.nextInt();
        }
    }

    void print() {
        for (student s : arr)
            System.out.print(s.age + " ");
        System.out.println("\n");
    }

    void buildMinHeap(int size) {
        for (int i = (size / 2) - 1; i >= 0; i--)
            minHeapify(i, size);
    }

    void minHeapify(int i, int size) {
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        int smallest = i;

        if (left < size && arr[left].age < arr[smallest].age)
            smallest = left;

        if (right < size && arr[right].age < arr[smallest].age)
            smallest = right;

        if (smallest != i) {
            student temp = arr[i];
            arr[i] = arr[smallest];
            arr[smallest] = temp;

            minHeapify(smallest, size);
        }
    }


    void buildMaxHeap(int size) {
        for (int i = (size / 2) - 1; i >= 0; i--)
            maxHeapify(i, size);
    }

    void maxHeapify(int i, int size) {
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        int largest = i;

        if (left < size && arr[left].age > arr[largest].age)
            largest = left;

        if (right < size && arr[right].age > arr[largest].age)
            largest = right;

        if (largest != i) {
            student temp = arr[i];
            arr[i] = arr[largest];
            arr[largest] = temp;

            maxHeapify(largest, size);
        }
    }

    void sortAscending() {
        int size = arr.length;

        buildMaxHeap(size); // use max heap

        for (int i = size - 1; i >= 0; i--) {
            student temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            maxHeapify(0, i); // heapify reduced heap
        }
    }

    void sortDescending() {
        int size = arr.length;

        buildMinHeap(size); // use min heap

        for (int i = size - 1; i >= 0; i--) {
            student temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            minHeapify(0, i); // heapify reduced heap
        }
    }
}
