package Heap;
import java.util.Scanner;

public class heap2 {

    student[] arr = new student[5];

    public heap2() {
        for (int i = 0; i < 5; i++)
            arr[i] = new student();
    }

    void minify(int s) {
        int lp = (s / 2) - 1;

        for (int i = lp; i >= 0; i--) {
            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if (right >= s) {
                if (left < s && arr[i].age > arr[left].age) {
                    student temp = arr[i];
                    arr[i] = arr[left];
                    arr[left] = temp;
                }
            }
            else {

                if (arr[right].age < arr[left].age) {
                    if (arr[i].age > arr[right].age) {
                        student temp = arr[i];
                        arr[i] = arr[right];
                        arr[right] = temp;
                    }
                }

                else {
                    if (arr[i].age > arr[left].age) {
                        student temp = arr[i];
                        arr[i] = arr[left];
                        arr[left] = temp;
                    }
                }
            }
        }
    }

    void sortDesc() {
        int size = arr.length;

        for (int i = 0; i < size - 1; i++) {
            minify(size - i);
            student temp = arr[size - i - 1];
            arr[size - i - 1] = arr[0];
            arr[0] = temp;
        }
    }

    void maxify(int s) {
        int lp = (s / 2) - 1;

        for (int i = lp; i >= 0; i--) {
            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if (right >= s) {
                if (left < s && arr[i].age < arr[left].age) {
                    student temp = arr[i];
                    arr[i] = arr[left];
                    arr[left] = temp;
                }
            }

            else {

                if (arr[right].age > arr[left].age) {
                    if (arr[i].age < arr[right].age) {
                        student temp = arr[i];
                        arr[i] = arr[right];
                        arr[right] = temp;
                    }
                }

                else {
                    if (arr[i].age < arr[left].age) {
                        student temp = arr[i];
                        arr[i] = arr[left];
                        arr[left] = temp;
                    }
                }
            }
        }
    }

    void sortAsen() {
        int size = arr.length;

        for (int i = 0; i < size; i++) {
            maxify(size - i);
            student temp = arr[size - i - 1];
            arr[size - i - 1] = arr[0];
            arr[0] = temp;
        }
    }

    void input() {
        Scanner cin = new Scanner(System.in);
        System.out.println("Enter 5 ages:");
        for (int i = 0; i < 5; i++)
            arr[i].age = cin.nextInt();
    }

    void display() {
        System.out.println("Array:");
        for (int i = 0; i < 5; i++)
            System.out.println(arr[i].age);
    }
}
