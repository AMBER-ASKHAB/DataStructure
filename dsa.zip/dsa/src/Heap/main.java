package Heap;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {

        heap h = new heap();
        Scanner cin = new Scanner(System.in);

        int ch;

        while (true) {
            System.out.println("Press 1 to take input");
            System.out.println("Press 2 to sort in ascending order");
            System.out.println("Press 3 to sort in descending order");
            System.out.println("Press 4 to exit");
            System.out.print("Enter your choice: ");
            ch = cin.nextInt();
            System.out.println();

            switch (ch) {
                case 1:
                    h.takeInput();
                    System.out.println("Input recorded.\n");
                    break;

                case 2:
                    h.sortAscending();
                    System.out.println("Sorted in Ascending Order:");
                    h.print();
                    break;

                case 3:
                    h.sortDescending();
                    System.out.println("Sorted in Descending Order:");
                    h.print();
                    break;

                case 4:
                    System.out.println("Exiting program...");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Try again.\n");
            }
        }
    }
}
