package Heap;


public class student {
    int age;

    public student() {
        age = 0;
    }

    public student(int a) {
        age = a;
    }
}
