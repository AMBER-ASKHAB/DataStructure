package Plaindrome;

public class main {
    static void main() {
        palindrome p=new palindrome();
        p.checkPalindrome("mad");
    }
}
