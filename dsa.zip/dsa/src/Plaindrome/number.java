package Plaindrome;

public class number {
    char c;
}
