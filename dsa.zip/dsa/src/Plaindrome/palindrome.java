package Plaindrome;

public class palindrome {
    stack s=new stack();
    boolean ispalindrome=false;
    public void checkPalindrome(String num)
    {
        char[] c = num.toCharArray();
        int count=0;
        for(int i=0;i<c.length;i++)
        {
           s.push(c[i]);
        }
        while(!s.isEmpty())
        {
            System.out.println(s.peek());
            if(c[count]!=s.pop())
            {
                System.out.println(" not palindrome ");
                break;
            }
            count++;
        }
        if(count==c.length)
        {
            ispalindrome=true;
            System.out.println("palindrome ");
        }
    }
}
