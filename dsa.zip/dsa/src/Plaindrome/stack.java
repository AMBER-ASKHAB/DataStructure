package Plaindrome;

public class stack {
   number[] palindrome=new number[100] ;
   int c=0;

   stack()
   {
       for(int i=0;i<palindrome.length;i++)
           {
           palindrome[i]=new number();
           }
   }
   public void push(char ch)
   {
      palindrome[c].c=ch;
      c++;
   }
   public char pop()
   {
        c--;
        return palindrome[c].c;
   }
   public char peek()
   {
        return palindrome[c-1].c;
   }
   public boolean isEmpty()
   {
       return c==0;
   }
}
