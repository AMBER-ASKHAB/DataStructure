package Practice;

public class permutations {
    static void main(String[] args) {
        String num="abc";
        for(int i=0;i<num.length();i++)
        {

        }
    }
}
