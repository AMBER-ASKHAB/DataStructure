package Queue_Linkdlist;

public class Queue {
    node start;
    node end;

    public void enqueue(node n) {
        if(start == null) {
            start = n;
            end = n;
        }else
        {
            end.next = n;
            end = end.next;
        }
    }

    public node dequeue() {
        if(start == null) {
            System.out.println("Queue is empty");
            return null;
        }else {
            start = start.next;
            return start;
        }

    }

    public void displayall() {
        if(start == null) {
            System.out.println("Queue is empty");
        }else {
            node temp = start;
            while(temp != null) {
                System.out.println(temp.id);
                temp = temp.next;
            }
        }

    }
    public Boolean isEmpty() {
        if(start == null) {
            System.out.println("Queue is empty");
            return true;
        }else
            return false;
    }

}
