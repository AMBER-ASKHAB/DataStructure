package Queue_Linkdlist;

public class functionsQ {
    Queue q= new Queue();

    public void enqueue(node n)
    {
        q.enqueue(n);
    }
    public int dequeue()
    {
        node retval=q.dequeue();
        return retval.id;
    }
    public void display()
    {
        q.displayall();
    }
}
