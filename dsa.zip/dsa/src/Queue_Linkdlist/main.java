package Queue_Linkdlist;

import queue_ViaArray.customer;
import queue_ViaArray.functionsC;

import java.util.Scanner;

public class main {
    static void main(String[] args) {
        int n=0;
        Scanner sc=new Scanner(System.in);
        functionsQ f=new functionsQ();int choice;
        do {
            System.out.print("1.Enqueue\n2.Dequeue\n3.Display\nExit");
            choice=sc.nextInt();
            switch(choice)
            {
                case 1:System.out.print("Enter id");int id=sc.nextInt();
                    node c=new node(id);
                    f.enqueue(c);
                    break;
                case 2: int nid=f.dequeue();System.out.print("For id "+nid);break;
                case 3: f.display();break;

            }
        }while(choice<=3);
    }

}

