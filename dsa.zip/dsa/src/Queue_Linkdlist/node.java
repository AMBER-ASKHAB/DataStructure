package Queue_Linkdlist;

public class node {
    int id ;
    node next;

    node(int id) {
        this.id = id;

    }
}
