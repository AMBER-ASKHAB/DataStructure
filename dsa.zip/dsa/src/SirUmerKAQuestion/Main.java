package SirUmerKAQuestion;

public class Main {
    static void main() {
        int[] arr={0,1,0,1,1,2,0,1,2,1,0};
        int ind=0;
        int c=0;

        for(int i=0;i<arr.length && c<arr.length;i++) {
            if(arr[c]>arr[i]) {
                int temp=arr[i];
                arr[i]=arr[c];
                arr[c]=temp;

            }
            if(i==arr.length-1) {
                ind++;
                c++;
                i=ind;
            }
        }

        for(int j=0;j<arr.length;j++) {
            System.out.print(arr[j]+" ");
        }

    }
}
