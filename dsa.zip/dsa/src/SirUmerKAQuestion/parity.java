package SirUmerKAQuestion;

public class parity {
    static void main(String[] args) {
        int x = 0;

        for(int i = 1; i <= 5; i++) {

            for(int j = i; j <= 5; j++) {

                x += (i + j) % 2;

            }
        }
        System.out.println(x);
    }
}
