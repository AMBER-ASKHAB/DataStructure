package Stack;

public class IntNode {
    int[] stack = new int[100];
    int count = 0;

    void push(int n) {
        stack[count] = n;
        count++;
    }

    int pop() {
        return stack[--count];
    }

    boolean isEmpty() {
        return count == 0;
    }
}
