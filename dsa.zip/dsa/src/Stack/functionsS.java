package Stack;

import java.sql.SQLOutput;

public class functionsS {
    node[] stack= new node[100];
    int count=0;
    // constructor
    functionsS(){
        for(int i=0;i<stack.length;i++){
            stack[i]=new node();
        }
    }
    //push
    public void push(char n){
        stack[count].c=n;
        count++;
    }
    //pop
    public char pop(){
        if(count>0){
            char ch=stack[count-1].c;
            count--;
            return ch;
        }
        else{
            return ' ';
        }
    }
    // top
    public char top(){
        if(count>0){
            return stack[count-1].c;
        }else
         return ' ';
    }
    // ISEMPTY
    Boolean isEmpty(){
        if(count==0){
            return true;
        }
        return false;
    }

    String infixToPostfix(String infix){
        String postfix="";
        int i=0;
        while(i<infix.length())
        {
            char y=infix.charAt(i);
            if(y=='(' || y=='/'|| y=='+' || y==')'||y=='-'||y=='*'|| y=='^'){
                if(y=='('||isEmpty()){
                    push(y);
                    i++;
                }else if(y=='*' || y=='/') {
                    while(!isEmpty() && (top()=='*' || top()=='/')) {
                        postfix += pop() + ",";
                    }
                    push(y);
                    i++;
                }else if(y==')')
                {
                    while(top()!='(')
                    {
                        postfix+=pop() + ",";
                    }
                    pop();i++;
                }
                else if(y=='+' || y=='-') {
                    while(!isEmpty() && (top()=='+' || top()=='-' || top()=='*' || top()=='/')) {
                        postfix += pop() + ",";
                    }
                    push(y);
                    i++;
                }else if (y == '^') {
                    while (!isEmpty() && top() == '^') {
                        postfix += pop() + ",";
                    }
                    push(y);
                    i++;
                }

            }else
            {
                if(y>='0'&&y<='9')
                {
                    String number="";
                    while(i<infix.length()&& infix.charAt(i)>='0' && infix.charAt(i)<='9'){
                        number+=infix.charAt(i);
                        i++;
                    }
                    postfix+=number+",";i++;
                }else
                {
                    postfix+=y+",";
                    i++;
                }

            }
        }
        while(!isEmpty()) {
            postfix+=pop()+",";
        }
        return postfix;
    }
    int postixEvaluation(String postfix)
    {
        IntNode numstack = new IntNode();
        String[] postfixCommaSeperated = postfix.split(",");

        for (int i = 0; i < postfixCommaSeperated.length; i++) {
            String y = postfixCommaSeperated[i];

            if (y.length() == 0) continue;

            boolean isNumber = true;
            for (int j = 0; j < y.length(); j++) {
                if (y.charAt(j) < '0' || y.charAt(j) > '9') {
                    isNumber = false;
                    break;
                }
            }
            if (isNumber) {
                int num = Integer.parseInt(y);
                numstack.push(num);
            } else if (y.equals("+") || y.equals("-") || y.equals("*") || y.equals("/") || y.equals("^")) {
                int num1 = numstack.pop();
                int num2 = numstack.pop();
                int result = 0;

                switch (y.charAt(0)) {
                    case '+': result = num2 + num1; break;
                    case '-': result = num2 - num1; break;
                    case '*': result = num2 * num1; break;
                    case '/': result = num2 / num1; break;
                }
                numstack.push(result);
            } else {
                System.out.println("Invalid token: " + y);
            }
        }
        return numstack.pop();
    }

}
