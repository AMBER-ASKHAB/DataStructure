package Stack;

import java.util.Scanner;

public class main {
    public static void main() {
        Scanner sc = new Scanner(System.in);
        functionsS f=new functionsS();
        String infix;
        infix=sc.next();
        String m = f.infixToPostfix(infix);
        System.out.println("postfix= " + m);
        System.out.println("postfix evaluated= " + f.postixEvaluation(m));

    }
}
