package Stack;

public class node {
       char c;
}
