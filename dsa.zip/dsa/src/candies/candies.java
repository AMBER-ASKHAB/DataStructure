package candies;

public class candies {
    String color;
    candies next;
}
