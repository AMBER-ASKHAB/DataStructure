package candies;
import Plaindrome.stack;

import java.util.Arrays;
import java.util.Scanner;
public class functionsC {
    Scanner sc=new Scanner(System.in);
    stackC stack=new stackC();
    void addCandy()
    {
        candies c=new candies();
        System.out.println("Enter candy of color yellow , orange, blue ");
        c.color=sc.nextLine();
        stack.push(c);
    }
    public void removeCandyByColor()
    {
        System.out.println("Enter color to be removed yellow , orange, blue ");
        String color=sc.nextLine();

        stackC temp=new stackC();
        while(!stack.isEmpty())
        {
            if(!stack.peek().color.equals(color))
                temp.push(stack.pop());
            else
                stack.pop();
        }
        while(!temp.isEmpty())
        {
            stack.push(temp.pop());
        }
        return;
    }

    public void displayAll()
    {
        System.out.println("Candies");
        stack.display();
    }
}
