package candies;

import java.util.Scanner;

public class main {
    static void main() {
        Scanner sc = new Scanner(System.in);
      functionsC f=new functionsC();
      int choice;

      do {
          System.out.println("enter 1 to add candy \n 2 to remove candy \n 3 to display candies \n 4 to exit ");
          choice=sc.nextInt();
          switch (choice) {
              case 1: f.addCandy(); break;
              case 2: f.removeCandyByColor(); break;
              case 3:f.displayAll(); break;
              case 4: System.exit(0); break;
          }
      }while(choice<4);
    }
}
