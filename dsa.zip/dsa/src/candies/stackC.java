package candies;

public class stackC {
    candies start;
    int size=0;
    public void push(candies c)
    {
        c.next = start;
        start = c;
    }
    public int size()
    {
        candies temp=start;
        while(temp!=null)
        {
            size++;
            temp=temp.next;
        }
        return size;
    }
    public candies pop()
    {
        if(isEmpty())
        {
            System.out.println("Stack is empty");
            return null;
        }else
        {
            candies poped=start;
            start=start.next;
            return poped;
        }
    }
    public candies  peek()
    {
        return start;
    }
    public  boolean isEmpty()
    {
        return start==null;
    }
    public void display()
    {
        candies temp=start;
        while(temp!=null)
        {
            System.out.print(temp.color+" ");
            System.out.println();
            temp=temp.next;
        }
    }
}
