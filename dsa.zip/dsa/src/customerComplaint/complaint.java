package customerComplaint;

public class complaint {
    int complaint_id;
    String complaint_type,complaint_date,complaint_city;

}
