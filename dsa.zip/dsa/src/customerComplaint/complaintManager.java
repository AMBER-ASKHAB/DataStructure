package customerComplaint;

public class complaintManager {
    int c=0;
    int d=0;
    int flag=0;
    public void addComplaint(complaint c)
    {

    }
}
