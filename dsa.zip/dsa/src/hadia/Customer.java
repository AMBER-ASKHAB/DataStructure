package hadia;


public class Customer {
    int cid,cage;
    String cname,cgender,ctype;
    Customer next;
}
