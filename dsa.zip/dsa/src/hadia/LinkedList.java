package hadia;
import java.util.Scanner;

public class LinkedList {

    Customer start = null;


    int cvv = 0;
    int cvf = 0;
    int cnf = 0;
    int cvm = 0;
    int cnm = 0;

    int c = 0;

    Scanner cin = new Scanner(System.in);

    //----------------------------------------
    // ADD NEW CUSTOMER
    //----------------------------------------
    void addNewCus() {

        Customer x = new Customer();

        System.out.print("Enter customer id: ");
        x.cid = cin.nextInt();
        System.out.print("Enter customer name: ");
        x.cname = cin.next();
        System.out.print("Enter customer age: ");
        x.cage = cin.nextInt();
        System.out.print("Enter customer type (normal/vip/vvip): ");
        x.ctype = cin.next();
        System.out.print("Enter customer gender (male/female): ");
        x.cgender = cin.next();

        x.next = null;

        // auto upgrade normal customers
        if (x.ctype.equalsIgnoreCase("normal")) {

            if (x.cgender.equalsIgnoreCase("male")) {
                if (x.cage > 70) x.ctype = "vvip";
                else if (x.cage >= 60) x.ctype = "vip";
            }
            else { // female
                if (x.cage > 60) x.ctype = "vvip";
                else if (x.cage >= 50) x.ctype = "vip";
            }
        }

        // first insertion
        if (start == null) {
            start = x;

            // update counts
            if (x.ctype.equals("vvip")) cvv = 1;
            else if (x.ctype.equals("vip") && x.cgender.equals("female")) { cvf = 1; }
            else if (x.ctype.equals("normal") && x.cgender.equals("female")) { cnf = 1; }
            else if (x.ctype.equals("vip") && x.cgender.equals("male")) { cvm = 1; }
            else cnm = 1;

            c = 1;
            return;
        }

        addNodeByPriority(x);  // insert with priority system
    }

    //----------------------------------------
    // INSERT BASED ON PRIORITY (used everywhere)
    //----------------------------------------
    void addNodeByPriority(Customer x) {

        int insertPos;

        if (x.ctype.equalsIgnoreCase("vvip")) insertPos = cvv;
        else if (x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("female")) insertPos = cvv + cvf;
        else if (x.ctype.equalsIgnoreCase("normal") && x.cgender.equalsIgnoreCase("female")) insertPos = cvv + cvf + cnf;
        else if (x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("male")) insertPos = cvv + cvf + cnf + cvm;
        else insertPos = c;  // normal male → end

        Customer temp = start;
        Customer prev = null;
        int pos = 0;

        while (temp != null && pos < insertPos) {
            prev = temp;
            temp = temp.next;
            pos++;
        }

        if (prev == null) { // insert at head
            x.next = start;
            start = x;
        } else {
            x.next = temp;
            prev.next = x;
        }

        // update counters
        if (x.ctype.equalsIgnoreCase("vvip")) { cvv++; }
        else if (x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("female")) { cvf++; }
        else if (x.ctype.equalsIgnoreCase("normal") && x.cgender.equalsIgnoreCase("female")) { cnf++; }
        else if (x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("male")) { cvm++; }

        cnm++; // always increase because this represents boundary of full list

        c++;
    }

    //----------------------------------------
    // DEQUEUE (REMOVE FRONT)
    //----------------------------------------
    void dequeue() {

        if (start == null) {
            System.out.println("No customers to serve");
            return;
        }

        // update counters based on who is removed
        Customer x = start;

        if (x.ctype.equalsIgnoreCase("vvip")) cvv--;
        else if (x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("female")) cvf--;
        else if (x.ctype.equalsIgnoreCase("normal") && x.cgender.equalsIgnoreCase("female")) cnf--;
        else if (x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("male")) cvm--;

        cnm--;
        c--;

        start = start.next;
    }

    //----------------------------------------
    void displayAll() {
        if (start == null) {
            System.out.println("No customers to serve");
            return;
        }

        Customer t = start;
        while (t != null) {
            System.out.println("ID: " + t.cid + " | Name: " + t.cname + " | Age: " + t.cage +
                    " | Gender: " + t.cgender + " | Type: " + t.ctype);
            t = t.next;
        }
    }

    //----------------------------------------
    void displayYoung() {

        if (start == null) {
            System.out.println("No customers");
            return;
        }

        Customer t = start;
        Customer min = start;

        while (t != null) {
            if (t.cage < min.cage) min = t;
            t = t.next;
        }

        System.out.println("Youngest → " + min.cname + " (" + min.cage + ")");
    }

    //----------------------------------------
    void displayEldestMale() {

        Customer t = start;
        Customer max = null;

        while (t != null) {
            if (t.cgender.equalsIgnoreCase("male")) {
                if (max == null || t.cage > max.cage) max = t;
            }
            t = t.next;
        }

        if (max == null) System.out.println("No male customer found");
        else System.out.println("Eldest Male → " + max.cname + " (" + max.cage + ")");
    }

    //----------------------------------------
    void displayAllVVIP() {

        Customer t = start;
        int f = 0;

        while (t != null) {
            if (t.ctype.equalsIgnoreCase("vvip")) {
                System.out.println(t.cname + " (" + t.cage + ")");
                f = 1;
            }
            t = t.next;
        }

        if (f == 0) System.out.println("No VVIP customers");
    }

    //----------------------------------------
    void displayNormalF() {

        Customer t = start;
        int f = 0;

        while (t != null) {
            if (t.ctype.equalsIgnoreCase("normal") && t.cgender.equalsIgnoreCase("female")) {
                System.out.println(t.cname + " (" + t.cage + ")");
                f = 1;
            }
            t = t.next;
        }

        if (f == 0) System.out.println("No normal female customer");
    }

    //----------------------------------------
    void displayEldestVIP() {

        Customer t = start;
        Customer max = null;

        while (t != null) {
            if (t.ctype.equalsIgnoreCase("vip")) {
                if (max == null || t.cage > max.cage) max = t;
            }
            t = t.next;
        }

        if (max == null) System.out.println("No VIP customer");
        else System.out.println("Eldest VIP → " + max.cname + " (" + max.cage + ")");
    }

    //----------------------------------------
    void search(String name) {

        Customer t = start;
        int f = 0;

        while (t != null) {
            if (t.cname.equalsIgnoreCase(name)) {
                System.out.println("FOUND → ID: " + t.cid + ", Age: " + t.cage + ", Gender: " + t.cgender + ", Type: " + t.ctype);
                f = 1;
            }
            t = t.next;
        }

        if (f == 0) System.out.println("Customer NOT found");
    }

    //----------------------------------------
    void displayAverageVVIP() {

        if (cvv == 0) {
            System.out.println("No VVIP customers");
            return;
        }

        Customer t = start;
        int count = 0, sum = 0;

        while (t != null && count < cvv) {
            sum += t.cage;
            t = t.next;
            count++;
        }

        System.out.println("Average age of VVIP: " + ((double) sum / cvv));
    }

    //----------------------------------------
    void changeType(String name) {

        Customer t = start, prev = null, x = null;

        while (t != null) {
            if (t.cname.equalsIgnoreCase(name)) { x = t; break; }
            prev = t;
            t = t.next;
        }

        if (x == null) {
            System.out.println("Customer not found");
            return;
        }

        System.out.print("Enter updated type: ");
        x.ctype = cin.next();

        // remove from list first
        removeFromList(prev, x);

        // insert again according to new type
        addNodeByPriority(x);
    }

    //----------------------------------------
    void changeGender(String name) {

        Customer t = start, prev = null, x = null;

        while (t != null) {
            if (t.cname.equalsIgnoreCase(name)) { x = t; break; }
            prev = t;
            t = t.next;
        }

        if (x == null) {
            System.out.println("Customer not found");
            return;
        }

        System.out.print("Enter updated gender: ");
        x.cgender = cin.next();

        // auto type upgrade again
        if (x.ctype.equalsIgnoreCase("normal")) {

            if (x.cgender.equalsIgnoreCase("male")) {
                if (x.cage > 70) x.ctype = "vvip";
                else if (x.cage >= 60) x.ctype = "vip";
            }
            else {
                if (x.cage > 60) x.ctype = "vvip";
                else if (x.cage >= 50) x.ctype = "vip";
            }
        }

        removeFromList(prev, x);
        addNodeByPriority(x);
    }

    //----------------------------------------
    // helper
    void removeFromList(Customer prev, Customer x) {

        if (prev == null) start = x.next;
        else prev.next = x.next;

        // update counters
        if (x.ctype.equalsIgnoreCase("vvip")) cvv--;
        else if (x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("female")) cvf--;
        else if (x.ctype.equalsIgnoreCase("normal") && x.cgender.equalsIgnoreCase("female")) cnf--;
        else if (x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("male")) cvm--;

        cnm--;
        c--;

        x.next = null;
    }
}
