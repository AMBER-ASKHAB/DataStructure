package hadia;
import java.util.Scanner;


public class main2 {
    public static void main(String[] args) {
        int ch;
        LinkedList f=new LinkedList();
        Scanner cin=new Scanner(System.in);
        do
        {
            System.out.println("1. Add new customer (any type, any gender, any age )\n2." +
                    " Remove the customer when he/she served "+  "\n3. Display all customers"  +
                    "\n4. Display Youngest customer"+ "\n5. Display eldest male customer" +
                    "\n6. Display all VIIP customers "+"\n7. Display female normal customer" +
                    "\n8. Display eldest VIP customer" +"\n9. Search and display customer in the list for given name" +
                    "\n10. Display average age of the VIIP customers in the list" +
                    "\n11. Change the type of customer" +"\n12. Change the gender of the customer" +
                    "\nEnter your choice: ");
            ch=cin.nextInt();
            switch(ch)
            {
                case 1:
                    f.addNewCus();
                    break;
                case 2:
                    f.dequeue();
                    break;
                case 3:
                    f.displayAll();
                    break;
                case 4:
                    f.displayYoung();
                    break;
                case 5:
                    f.displayEldestMale();
                    break;
                case 6:
                    f.displayAllVVIP();
                    break;
                case 7:
                    f.displayNormalF();
                    break;
                case 8:
                    f.displayEldestVIP();
                    break;
                case 9:
                    String name;
                    System.out.println("Enter name to search : ");
                    name=cin.next();
                    f.search(name);
                    break;
                case 10:
                    f.displayAverageVVIP();
                    break;
                case 11:
                    String name2;
                    System.out.println("Enter name:");
                    name2=cin.next();
                    f.changeType(name2);
                    break;
                case 12:
                    String name1;
                    System.out.println("Enter name:");
                    name1=cin.next();
                    f.changeGender(name1);
                    break;
                default:
                    System.out.println("Exiting");


            }

        }while(ch!=13);
    }

}
