package hadia;
import java.util.Scanner;


public class prioirtyQueue{
    Customer []arr=new Customer[3];
    int cvv=0,cvf=0,cvm=0,cnf=0,cnm=0,c=0;
    Scanner cin=new Scanner(System.in);

    public prioirtyQueue()
    {
        for(int i=0;i<3;i++)
            arr[i]=null;
    }

    void addNewCus() {
        if(c == arr.length) { // Check at the very start
            System.out.println("Queue is full");
            return;
        }

        Customer x = new Customer();
        System.out.println("Enter customer id:");
        x.cid = cin.nextInt();
        System.out.println("Enter customer name:");
        x.cname = cin.next();
        System.out.println("Enter customer age:");
        x.cage = cin.nextInt();
        System.out.println("Enter customer type:");
        x.ctype = cin.next();
        System.out.println("Enter customer gender:");
        x.cgender = cin.next();


        if(x.ctype.equalsIgnoreCase("normal")) {
            if(x.cgender.equalsIgnoreCase("male")) {
                if(x.cage > 70) x.ctype = "vvip";
                else if(x.cage >= 60) x.ctype = "vip";
            } else {
                if(x.cage > 60) x.ctype = "vvip";
                else if(x.cage >= 50) x.ctype = "vip";
            }
        }


        if(c == arr.length) {
            System.out.println("Queue is full");
            return;
        }

        // Insert based on type and gender
        if(x.ctype.equalsIgnoreCase("vvip")) {
            for(int i = c; i > cvv; i--)
                arr[i] = arr[i - 1]; // safe now
            arr[cvv] = x;
            cvv++; cvf++; cnf++; cvm++; cnm++; // update counters
            c++;
        }
        else if(x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("female")) {
            for(int i = c; i > cvf; i--)
                arr[i] = arr[i - 1];
            arr[cvf] = x;
            cvf++; cnf++; cvm++; cnm++;
            c++;
        }
        else if(x.ctype.equalsIgnoreCase("normal") && x.cgender.equalsIgnoreCase("female")) {
            for(int i = c; i > cnf; i--)
                arr[i] = arr[i - 1];
            arr[cnf] = x;
            cnf++; cvm++; cnm++;
            c++;
        }
        else if(x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("male")) {
            for(int i = c; i > cvm; i--)
                arr[i] = arr[i - 1];
            arr[cvm] = x;
            cvm++; cnm++;
            c++;
        }
        else {
            arr[cnm] = x;
            cnm++;
            c++;
        }

        System.out.println("Customer added successfully!");
    }

    void dequeue()
    {
        if(c==0)
            System.out.println("No customers to serve");
        else
        {
            for(int i=0;i<c-1;i++)
                arr[i]=arr[i+1];

            arr[c-1] = null;
            c--;

            if(cvv>c) cvv=c;
            if(cvf>c) cvf=c;
            if(cvm>c) cvm=c;
            if(cnf>c) cnf=c;
            if(cnm>c) cnm=c;
        }
    }

    void displayAll()
    {
        if(c==0)
            System.out.println("No customers to serve");
        else
        {
            for(int i=0;i<c;i++)
            {
                System.out.println("Name: "+arr[i].cname+"\nId: "+arr[i].cid+
                        "\nGender: "+arr[i].cgender+"\nAge: "+arr[i].cage+"\nType: "+arr[i].ctype);
            }
        }
    }

    void displayYoung()
    {
        if(c==0)
            System.out.println("No customers to serve");
        else
        {
            Customer max=arr[0];
            for(int i=0;i<c;i++)
            {
                if(arr[i].cage<max.cage)
                    max=arr[i];
            }
            System.out.println("Youngest customer\nId: "+max.cid+"\nName: "+max.cname+"\nAge: "+max.cage);
        }
    }

    void displayEldestMale()
    {
        if(c==0)
            System.out.println("No customers to serve");
        else
        {
            Customer max = null;
            for(int i=0;i<c;i++)
            {
                if(arr[i].cgender.equalsIgnoreCase("male"))
                {
                    if(max == null || arr[i].cage > max.cage)
                        max = arr[i];
                }
            }
            if(max!=null)
                System.out.println("Eldest customer\nId: "+max.cid+"\nName: "+max.cname+"\nAge: "+max.cage);
            else
                System.out.println("No male customer found");
        }
    }

    void displayAllVVIP()
    {
        if(c==0)
            System.out.println("No customers");
        else
        {
            for(int i=0;i<c;i++)
            {
                if(arr[i].ctype.equalsIgnoreCase("vvip"))
                {
                    System.out.println("Name: "+arr[i].cname+"\nAge: "+arr[i].cage+
                            "\nType: "+arr[i].ctype+"\nGender: "+arr[i].cgender);
                }
            }
        }
    }

    void displayNormalF()
    {
        int flag=0;
        if(c==0)
            System.out.println("No customers to show");
        else
        {
            for(int i=0;i<c;i++)
            {
                if(arr[i].ctype.equalsIgnoreCase("normal")&& arr[i].cgender.equalsIgnoreCase("female"))
                {
                    System.out.println("id: "+arr[i].cid+"\nName: "+arr[i].cname+"\nAge: "+
                            arr[i].cage+"\nGender: "+arr[i].cgender+"\nType: "+arr[i].ctype);
                    flag=1;
                }
            }
        }
        if(flag==0)
            System.out.println("No normal female found");
    }

    void displayEldestVIP()
    {
        if(c==0)
            System.out.println("No customers ");
        else
        {
            Customer max = null;
            for(int i=0;i<c;i++)
            {
                if(arr[i].ctype.equalsIgnoreCase("vip"))
                {
                    if(max == null || arr[i].cage > max.cage)
                        max = arr[i];
                }
            }
            if(max != null)
                System.out.println("Eldest VIP\nId: "+max.cid+"\nName: "+max.cname+
                        "\nAge: "+max.cage+"\nType: "+max.ctype+"\nGender: "+max.cgender);
            else
                System.out.println("No VIP customer found");
        }
    }

    void search(String name)
    {
        int f=0;
        if(c==0)
            System.out.println("No customers ");
        else
        {
            for(int i=0;i<c;i++)
            {
                if(arr[i].cname.equalsIgnoreCase(name))
                {
                    System.out.println("Id: "+arr[i].cid+"\nName:"+arr[i].cname+"\nAge: "
                            +arr[i].cage+"\nType: "+arr[i].ctype+"\nGender: "+arr[i].cgender);

                    f=1;
                }
            }
        }
        if(f==0)
            System.out.println("Customer not found");
    }

    void displayAverageVVIP()
    {
        if(cvv==0)
            System.out.println("No VVIP customers");
        else
        {
            int sum=0;
            for(int i=0;i<cvv;i++)
                sum+=arr[i].cage;

            double avg = (double)sum/cvv;
            System.out.println("average: "+avg);
        }
    }

    void changeType(int ind)
    {
        if(ind >= c)
            System.out.println("Invalid index");
        else
        {
            Customer x = arr[ind];
            System.out.println("Enter updated type:");
            x.ctype = cin.next();

            if(x.ctype.equalsIgnoreCase("normal"))
            {
                if(x.cgender.equalsIgnoreCase("male"))
                {
                    if(x.cage > 70) x.ctype = "vvip";
                    else if(x.cage >= 60) x.ctype = "vip";
                }
                else
                {
                    if(x.cage > 60) x.ctype = "vvip";
                    else if(x.cage >= 50) x.ctype = "vip";
                }
            }

            for(int i = ind; i < c - 1; i++)
                arr[i] = arr[i + 1];

            c--;

            if(x.ctype.equalsIgnoreCase("vvip"))
            {
                for(int i = c; i > cvv; i--)
                    arr[i] = arr[i - 1];

                arr[cvv] = x;
                cvv++; cvf++; cnf++; cvm++; cnm++;
                c++;
            }
            else if(x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("female"))
            {
                for(int i = c; i > cvf; i--)
                    arr[i] = arr[i - 1];

                arr[cvf] = x;
                cvf++; cnf++; cvm++; cnm++;
                c++;
            }
            else if(x.ctype.equalsIgnoreCase("normal") && x.cgender.equalsIgnoreCase("female"))
            {
                for(int i = c; i > cnf; i--)
                    arr[i] = arr[i - 1];

                arr[cnf] = x;
                cnf++; cvm++; cnm++;
                c++;
            }
            else if(x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("male"))
            {
                for(int i = c; i > cvm; i--)
                    arr[i] = arr[i - 1];

                arr[cvm] = x;
                cvm++; cnm++;
                c++;
            }
            else
            {
                arr[cnm] = x;
                cnm++;
                c++;
            }
        }
    }

    void changeGender(int ind)
    {
        if(ind >= c)
            System.out.println("Invalid index");
        else
        {
            Customer x = arr[ind];
            System.out.println("Enter updated gender: ");
            x.cgender = cin.next();

            if(x.ctype.equalsIgnoreCase("normal"))
            {
                if(x.cgender.equalsIgnoreCase("male"))
                {
                    if(x.cage > 70) x.ctype = "vvip";
                    else if(x.cage >= 60) x.ctype = "vip";
                }
                else
                {
                    if(x.cage > 60) x.ctype = "vvip";
                    else if(x.cage >= 50) x.ctype = "vip";
                }
            }

            for(int i = ind; i < c - 1; i++)
                arr[i] = arr[i + 1];

            c--;

            if(x.ctype.equalsIgnoreCase("vvip"))
            {
                for(int i = c; i > cvv; i--)
                    arr[i] = arr[i - 1];

                arr[cvv] = x;
                cvv++; cvf++; cnf++; cvm++; cnm++;
                c++;
            }
            else if(x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("female"))
            {
                for(int i = c; i > cvf; i--)
                    arr[i] = arr[i - 1];

                arr[cvf] = x;
                cvf++; cnf++; cvm++; cnm++;
                c++;
            }
            else if(x.ctype.equalsIgnoreCase("normal") && x.cgender.equalsIgnoreCase("female"))
            {
                for(int i = c; i > cnf; i--)
                    arr[i] = arr[i - 1];

                arr[cnf] = x;
                cnf++; cvm++; cnm++;
                c++;
            }
            else if(x.ctype.equalsIgnoreCase("vip") && x.cgender.equalsIgnoreCase("male"))
            {
                for(int i = c; i > cvm; i--)
                    arr[i] = arr[i - 1];

                arr[cvm] = x;
                cvm++; cnm++;
                c++;
            }
            else
            {
                arr[cnm] = x;
                cnm++;
                c++;
            }
        }
    }
}




















































































































