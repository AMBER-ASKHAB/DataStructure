package hadia_final;

import java.util.Scanner;

public class BankingSystem {
    customer[] queue = new customer[100];
    int c = 0;
    historyStack history;
    Scanner cin;

    BankingSystem() {
        this.cin = new Scanner(System.in);
        this.history = new historyStack();
    }

    void enqueue() {
        if (this.c == 100) {
            System.out.println("Queue is full.Please wait!");
        } else {
            customer x = new customer();
            System.out.println("Enter id:");
            x.id = this.cin.nextInt();
            System.out.println("Enter name: ");
            x.name = this.cin.next();
            System.out.println("Enter gender: ");
            x.gender = this.cin.next();
            System.out.println("Enter process time: ");
            x.process = this.cin.nextInt();
            System.out.println("Enter balance: ");
            x.balance = this.cin.nextDouble();
            this.queue[this.c] = x;
            System.out.println("Enter account type(Saving/Checking)");
            x.accountType = this.cin.next();
            ++this.c;
            this.sortDesc();
        }

    }

    void minify(int s) {
        int lp = s / 2 - 1;

        for(int i = lp; i >= 0; --i) {
            if (i * 2 + 2 == s) {
                if (this.queue[i].process > this.queue[i * 2 + 1].process) {
                    customer temp = this.queue[i];
                    this.queue[i] = this.queue[i * 2 + 1];
                    this.queue[i * 2 + 1] = temp;
                }
            } else if (this.queue[i * 2 + 1].process > this.queue[i * 2 + 2].process) {
                if (this.queue[i].process > this.queue[i * 2 + 2].process) {
                    customer temp = this.queue[i];
                    this.queue[i] = this.queue[i * 2 + 2];
                    this.queue[i * 2 + 2] = temp;
                }
            } else if (this.queue[i].process > this.queue[i * 2 + 1].process) {
                customer temp = this.queue[i];
                this.queue[i] = this.queue[i * 2 + 1];
                this.queue[i * 2 + 1] = temp;
            }
        }

    }

    void sortDesc() {
        int s = this.c;

        for(int i = 0; i < this.c; ++i) {
            this.minify(s - i);
            customer temp = this.queue[this.c - i - 1];
            this.queue[this.c - i - 1] = this.queue[0];
            this.queue[0] = temp;
        }

    }

    void allocateProcessor() {
        if (this.c == 0) {
            System.out.println("No customers to serve");
        } else {
            System.out.println("Process is beig allocated to " + this.queue[this.c - 1].name);
            int q = 2;
            customer var10000 = this.queue[this.c - 1];
            var10000.process -= q;
            if (this.queue[this.c - 1].process <= 0) {
                --this.c;
            }
        }

        this.sortDesc();
    }

    void findCustomer(String name) {
        int flag = 0;
        if (this.c == 0) {
            System.out.println("No customers to search");
        } else {
            for(int i = 0; i < this.c; ++i) {
                if (this.queue[i].name.equalsIgnoreCase(name)) {
                    System.out.println("Customer found at index " + i + "\nId: " + this.queue[i].id + "\nName: " + this.queue[i].name + "\nGender: " + this.queue[i].gender);
                    flag = 1;
                }
            }
        }

        if (flag == 0) {
            System.out.println("Not found");
        }

    }

    void makeTransaction() {
        int flag = 0;
        if (this.c == 0) {
            System.out.println("No customers");
        } else {
            System.out.println("Enter id of customer that want to make transaction:");
            int id = this.cin.nextInt();

            for(int i = 0; i < this.c; ++i) {
                if (this.queue[i].id == id) {
                    System.out.println("Enter amount: ");
                    double amount = this.cin.nextDouble();
                    if (amount > this.queue[i].balance) {
                        System.out.println("Insufficient balance");
                    } else {
                        customer var10000 = this.queue[i];
                        var10000.balance -= amount;
                        System.out.println("Amount of " + amount + " has been transacted.Your available balance " + "is now " + this.queue[i].balance);
                        this.queue[i].amount = amount;
                        HistoryNode h = new HistoryNode();
                        h.id = this.queue[i].id;
                        h.name = this.queue[i].name;
                        h.amount = this.queue[i].amount;
                        h.next = null;
                        this.history.push(h);
                    }

                    flag = 1;
                    break;
                }
            }
        }

        if (flag == 0) {
            System.out.println("Customer not found ");
        }

    }

    void displayAllWithSameAccountType(String type) {
        int flag = 0;
        if (this.c == 0) {
            System.out.println("No customers to show");
        } else {
            for(int i = 0; i < this.c; ++i) {
                if (this.queue[i].accountType.equalsIgnoreCase(type)) {
                    System.out.println("Id: " + this.queue[i].id + "\nName: " + this.queue[i].name + "\nType: " + this.queue[i].accountType + "\nBalance: " + this.queue[i].balance);
                    flag = 1;
                }
            }
        }

        if (flag == 0) {
            System.out.println("No such account found");
        }

    }

    void deposit(int id) {
        int f = 0;
        if (this.c == 0) {
            System.out.println("No customers ");
        } else {
            for(int i = 0; i < this.c; ++i) {
                if (this.queue[i].id == id) {
                    System.out.println("Enter amount t=you want to deposit:");
                    double amount = this.cin.nextDouble();
                    customer var10000 = this.queue[i];
                    var10000.balance += amount;
                    System.out.println(this.queue[i].name + " your updated balance is " + this.queue[i].balance);
                    f = 1;
                }
            }
        }

        if (f == 0) {
            System.out.println("No customer found for given id");
        }

    }

    void display() {
        if (this.c == 0) {
            System.out.println("No customers to show");
        } else {
            for(int i = 0; i < this.c; ++i) {
                System.out.println("Id: " + this.queue[i].id + "\nName: " + this.queue[i].name + "\nType: " + this.queue[i].accountType + "\nBalance: " + this.queue[i].balance + "\nProcess time: " + this.queue[i].process);
            }
        }

    }
}