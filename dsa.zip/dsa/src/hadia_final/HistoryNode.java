package hadia_final;

public class HistoryNode {
    int id;
    String name;
    double amount;
    HistoryNode next = null;

    HistoryNode() {
    }
}