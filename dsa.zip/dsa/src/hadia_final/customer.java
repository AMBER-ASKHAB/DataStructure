package hadia_final;

public class customer {
    int id;
    String name;
    String gender;
    String accountType;
    int process;
    boolean isActive;
    double balance;
    double amount;
}
