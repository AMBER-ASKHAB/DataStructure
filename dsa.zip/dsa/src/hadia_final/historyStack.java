package hadia_final;

public class historyStack {
    HistoryNode top;

    public void push(HistoryNode node) {
        if (this.top == null) {
            this.top = node;
        } else {
            node.next = this.top;
            this.top = node;
        }

    }

    public void showHistory(int id) {
        if (this.top == null) {
            System.out.println("Transaction history is empty");
        } else {
            HistoryNode temp = this.top;

            boolean found;
            for(found = false; temp != null; temp = temp.next) {
                if (temp.id == id) {
                    System.out.println("Name: " + temp.name + "\nId: " + temp.id + "\nAmount transacted: " + temp.amount + "\n");
                    found = true;
                }
            }

            if (!found) {
                System.out.println("No transactions found for this customer");
            }
        }

    }
}