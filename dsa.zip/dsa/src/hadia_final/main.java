package hadia_final;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        historyStack x = new historyStack();
        Scanner cin = new Scanner(System.in);
        BankingSystem f = new BankingSystem();

        int ch;
        do {
            System.out.println("--------Banking System---------");
            System.out.println("Press 1 to add customer");
            System.out.println("Press 2 to serve Customer");
            System.out.println("Press 3 to to find Customer (By name)");
            System.out.println("Press 4 to make transaction");
            System.out.println("Press 5 to display All customers with same account type");
            System.out.println("Press 6 to display all customers");
            System.out.println("Press 7 to deposit money ");
            System.out.println("Press 8 to show transaction history against id");
            System.out.println("Press 9 to exit");
            System.out.println("Please enter your choice: ");
            ch = cin.nextInt();
            switch (ch) {
                case 1:
                    f.enqueue();
                    break;
                case 2:
                    f.allocateProcessor();
                    break;
                case 3:
                    System.out.println("Enter name you want to search:");
                    String name = cin.next();
                    f.findCustomer(name);
                    break;
                case 4:
                    f.makeTransaction();
                    break;
                case 5:
                    System.out.println("Enter account type:");
                    String type = cin.next();
                    f.displayAllWithSameAccountType(type);
                    break;
                case 6:
                    f.display();
                    break;
                case 7:
                    System.out.println("Enter id for which you wanna deposit money:");
                    int id = cin.nextInt();
                    f.deposit(id);
                    break;
                case 8:
                    System.out.println("Enter id for which you want transaction history: ");
                    int i = cin.nextInt();
                    x.showHistory(i);
                    break;
                default:
                    System.out.println("Exiting!");
            }
        } while(ch != 9);

    }
}
