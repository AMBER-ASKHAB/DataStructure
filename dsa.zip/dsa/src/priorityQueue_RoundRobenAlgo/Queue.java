package priorityQueue_RoundRobenAlgo;

public class Queue {
    processes[] p=new processes[3];
    int count=0;
    int flag=0;
    int d=0;
    int c=0;
    Queue (){
        for(int i=0;i<p.length;i++){
            p[i]=new processes();
        }
    }
    public void enqueue(processes obj) {
        if (c == d && flag == 1) {
            System.out.println("Queue is full! You can't insert ID=" + obj.id);
            return;
        }

        p[c] = obj;
        count++;
        System.out.println("Inserted ID=" + obj.id + " at index " + c);

        if (c == p.length - 1) {
            c = 0;
            flag = 1;
        } else {
            c++;
        }

        System.out.println("c =" + c + ", d=" + d + ", flag=" + flag + ", count=" + count);
    }
    public processes dequeue() {
        if (c == d && flag == 0) {
            System.out.println("Queue is empty!");
            return null;
        }

        processes temp = p[d];
        System.out.println("Removed ID=" + temp.id + " from index " + d);
        count--;


        if (d == p.length - 1) {
            d = 0;
            flag = 0;
        } else {
            d++;
        }

        System.out.println("c=" + c + ", d=" + d + ", flag=" + flag + ", count=" + count);
        return temp;
    }

}
