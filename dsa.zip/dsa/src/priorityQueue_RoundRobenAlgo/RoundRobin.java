package priorityQueue_RoundRobenAlgo;
import java.util.Scanner;
public class RoundRobin {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Queue q = new  Queue();

        System.out.println("Enter number of processes: ");
        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {
            System.out.print("Enter Process ID: ");
            int id = sc.nextInt();
            System.out.print("Enter Time: ");
            int bt = sc.nextInt();

            processes p = new processes(id, bt);
            q.enqueue(p);
        }

        System.out.print("Enter Time Quantum: ");
        int quantum = sc.nextInt();

        System.out.println("\n--- Round Robin Execution ---");

        int time = 0;
        int completed = 0;

        while(completed < n) {
            processes currentP = q.dequeue();
            if(currentP == null) {
                break;
            }

            if(currentP.remainingTime >0) {

                if (currentP.remainingTime > quantum) {
                    System.out.println("Time " + time +": Process " + currentP.id + " executed for " + quantum);
                    currentP.remainingTime -= quantum;
                    time += quantum;
                    q.enqueue(currentP);
                }
                else {
                    System.out.println("Time " + time + " Process " + currentP.id + " completed");
                    time += currentP.remainingTime;
                    currentP.remainingTime -= quantum;
                    completed++;
                }
        }}
        System.out.println("\nAll processes completed at time: " + time);
    }

}
