package priorityQueue_RoundRobenAlgo;

public class processes {
    int id;
    int Time;
    int remainingTime;

    processes(int id, int burstTime) {
        this.id = id;
        this.Time = burstTime;
        this.remainingTime = burstTime;
    }
processes()
{

}

}
