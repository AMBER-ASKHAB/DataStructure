package priorityQueue_primtive;

public class PreemptiveQueue {
    process start;
    process end;
    int qTime=2;
    public void enqueue(process p) {
        if(isEmpty()) {
            start = p;
        }else if (p.priorityTime < start.priorityTime) {
            p.next = start;
            start = p;
        } else
        {
            process temp=start;
            while(temp.next!=null && temp.next.priorityTime<=p.priorityTime)
            {
                temp=temp.next;
            }
            p.next=temp.next;
            temp.next=p;
        }
    }

    public void dequeue() {
        if(isEmpty()) {
            System.out.println("queue is empty");
        }else
        {
            process temp=start;
            start=start.next;

            System.out.println("SERVING ID : "+temp.name+", NAME: "+temp.name+", PRIORITY: "
                    +temp.priorityTime+", REMAINING TIME: "+temp.rTime);

            temp.rTime-=qTime;
            if(temp.rTime>0)
            {
                temp.next=null;
                enqueue(temp);
            }else {
                System.out.println(temp.name + " is completed");
                if(start==null)
                    end=null;
            }
        }
    }

    public void displayQueue()
    {
        if(isEmpty()) {
            System.out.println("No pending processes ");
        }else
        {
            process temp=start;
            while(temp!=null)
            {
                System.out.println("ID : "+temp.id+", NAME: "+temp.name+", PRIORITY: "
                        +temp.priorityTime+", REMAINING TIME: "+temp.rTime);
                temp=temp.next;
            }
        }
    }
    public boolean isEmpty() {
        if(start==null)
            return true;
        return false;
    }
}
