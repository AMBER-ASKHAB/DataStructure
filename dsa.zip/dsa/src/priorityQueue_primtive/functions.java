package priorityQueue_primtive;

public class functions {
    PreemptiveQueue q=new PreemptiveQueue();

    public void enqueue(process r)
    {
        q.enqueue(r);
    }
    public void serveRequest()
    {
        q.dequeue();
    }
    public void showRemainingRequest()
    {
        q.displayQueue();
    }
}
