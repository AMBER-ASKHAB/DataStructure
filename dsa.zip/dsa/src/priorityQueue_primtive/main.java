package priorityQueue_primtive;

import java.util.Scanner;

public class main {
    static void main() {
        functions f=new functions();
        Scanner sc=new Scanner(System.in);
        System.out.println(" CPU SCHEDULING ");
        int choice;
        do {
            System.out.println(" 1.ADD PROCESS \n 2.PROCESS REQUEST \n 3.DISPLAY REMAINING \n 4.EXIT");
            choice=sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Enter PROCESS ID");
                    int id=sc.nextInt();
                    System.out.println("Enter PROCESS NAME");
                    String name=sc.next();
                    System.out.println("Enter PROCESS PRIORITY");
                    int priority=sc.nextInt();
                    process p=new process(id,name,priority);
                    f.enqueue(p);
                    break;

                case 2:
                    f.serveRequest();
                    break;
                case 3:
                    f.showRemainingRequest();
                    break;
                default:
                    System.out.println("Wrong choice");
            }
        }while(choice<=4);
    }
}
