package priorityQueue_primtive;

public class process {
    int id;
    String name;
    process next;
    int priorityTime;
    int rTime;
    public process(int id, String name,int priorityTime) {
        this.id = id;
        this.name = name;
        this.priorityTime = priorityTime;
        rTime = priorityTime;
    }
}
