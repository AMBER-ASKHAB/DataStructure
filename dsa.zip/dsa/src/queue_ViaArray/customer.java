package queue_ViaArray;

public class customer {
    int id,age;
    customer()
    {

    }
    customer(int id, int age) {
        this.id = id;
        this.age = age;
    }
}
