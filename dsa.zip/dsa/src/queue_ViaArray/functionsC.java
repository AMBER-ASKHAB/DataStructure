package queue_ViaArray;

public class functionsC {
    customer[] C=new customer[3];
    int count=0;
    int flag=0;
    int d=0;
    int c=0;
    functionsC(){
        for(int i=0;i<3;i++){
            C[i]=new customer();
        }
    }

    public void enqueue(customer obj) {
        if (c == d && flag == 1) {
            System.out.println("Queue is full! You can't insert ID=" + obj.id);
            return;
        }

        C[c] = obj;
        count++;
        System.out.println("Inserted ID=" + obj.id + " at index " + c);

        if (c == C.length - 1) {
            c = 0;
            flag = 1;
        } else {
            c++;
        }

        System.out.println("c =" + c + ", d=" + d + ", flag=" + flag + ", count=" + count);
    }
    public customer dequeue() {
        if (c == d && flag == 0) {
            System.out.println("Queue is empty!");
            return null;
        }

        customer temp = C[d];
        System.out.println("Removed ID=" + temp.id + " from index " + d);
        count--;


        if (d == C.length - 1) {
            d = 0;
            flag = 0;
        } else {
            d++;
        }

        System.out.println("c=" + c + ", d=" + d + ", flag=" + flag + ", count=" + count);
        return temp;
    }

    public void display() {
        if (c == d && flag == 0) {
            System.out.println("All complaints have been resolved.");
            return;
        }

        System.out.println("Remaining Coustomers:");

        if (c == d && flag == 1) {
            for (int i = 0; i < C.length; i++) {
                printCustomer(C[i]);
            }

        } else if (c < d && flag == 1) {
            for (int i = d; i < C.length; i++) {
                printCustomer(C[i]);
            }
            for (int i = 0; i < c; i++) {
                printCustomer(C[i]);
            }
        } else if (c > d && flag == 0) {
            for (int i = d; i < c; i++) {
                printCustomer(C[i]);
            }
        }
    }

    private void printCustomer(customer comp) {
        System.out.println("[" + comp.id+ ", " +
                comp.age + "]");
    }
}
