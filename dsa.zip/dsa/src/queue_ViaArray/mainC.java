package queue_ViaArray;
import java.util.Scanner;
public class mainC {

    public static void main(String args[])
    {
        int n=0;
        Scanner sc=new Scanner(System.in);
        functionsC f=new functionsC();

        int choice;
        do {
            System.out.print("1.Enqueue\n2.Dequeue\n3.Display\nExit");
             choice=sc.nextInt();
            switch(choice)
            {
                case 1:System.out.print("Enter id");int id=sc.nextInt();
                       System.out.print("Enter age");int age=sc.nextInt();
                       customer c=new customer(id,age);
                       f.enqueue(c);
                    break;
                case 2: f.dequeue();break;
                case 3: f.display();break;

            }
        }while(choice<3);
    }
}
