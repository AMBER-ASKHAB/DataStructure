package sjFbyArray;

public class process {
    int id ;
    int time;
    int rtime;
}
