package speedprogramming;

public class speed {
    static void main(String[] args) {
        int num=2;
        System.out.println(num);
        for ( int i=1,diff=4; i<10;i++,diff+=2)
        {
            num=num+diff;
            System.out.println(num);
        }
    }

}
