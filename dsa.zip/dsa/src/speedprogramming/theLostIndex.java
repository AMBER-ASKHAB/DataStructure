package speedprogramming;

public class theLostIndex {
    static void main() {
        int[] arr={1 ,2, 4, 2 ,5};
        int flag=-1;
        for(int i=1;i<arr.length-1;i++) {
            for(int j=0;j<arr.length;j++) {
                if(arr[j]==i) {
                    break;
                }else
                {
                     flag=i;
                }
           }
            if(flag!=-1) {
                System.out.println(flag);
            }

        }
    }
}
