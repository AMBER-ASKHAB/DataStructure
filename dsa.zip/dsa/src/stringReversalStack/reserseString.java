package stringReversalStack;

public class reserseString {
    public static void main(String[] args)
    {
        String s="Ahmed";
        stack stack=new stack();
        char[] c=s.toCharArray();

        for(int i=0;i<s.length();i++)
        {
            stack.push(c[i]);
        }

        String rev="";
        for(int i=0;i<c.length;i++)
        {
            rev+=stack.pop();
        }
        System.out.println("Reversed String: " + rev);
    }

}
