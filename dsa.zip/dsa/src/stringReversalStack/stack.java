package stringReversalStack;
public class stack {
    private char[] c = new char[100];
    private int count = 0;

    // Push a character onto stack
    public void push(char ch) {
        if (count == 100) {
            System.out.println("Stack Overflow! No space.");
        } else {
            c[count] = ch;
            count++;
        }
    }

    // Pop a character from stack
    public char pop() {
        if (count == 0) {
            System.out.println("Stack Underflow! Empty stack.");
            return '\0'; // return null character if stack is empty
        } else {
            return c[--count];
        }
    }

    // Peek top element
    public char peek() {
        if (count == 0) {
            System.out.println("Stack is empty!");
            return '\0';
        } else {
            return c[count - 1];
        }
    }

    // Display all elements
    public void display() {
        if (count == 0) {
            System.out.println("Stack is empty!");
        } else {
            System.out.print("Stack elements: ");
            for (int i = count - 1; i >= 0; i--) {
                System.out.print(c[i] + " ");
            }
            System.out.println();
        }
    }
}
