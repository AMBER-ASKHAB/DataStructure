package undo_Redo;

import java.util.Scanner;
public class NotepadArrayVersion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StackArray undoStack = new StackArray(100);
        StackArray redoStack = new StackArray(100);
        String text = "";

        undoStack.push(text);

        while (true) {
            System.out.println("\n==== MENU DRIVEN NOTEPAD ====");
            System.out.println("1. Write text");
            System.out.println("2. Undo");
            System.out.println("3. Redo");
            System.out.println("4. Show current text");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter new text to append: ");
                    String newText = sc.nextLine();
                    text += newText + "\n";
                    undoStack.push(text);
                    redoStack.clear();
                    System.out.println("Text added!");
                    break;

                case 2:
                    if (!undoStack.isEmpty()) {
                        String current = undoStack.pop();
                        if (!undoStack.isEmpty()) {
                            redoStack.push(current);
                            text = undoStack.peek();
                            System.out.println("Undo successful!");
                        } else {
                            undoStack.push(current); // restore
                            System.out.println("Nothing to undo!");
                        }
                    }
                    break;

                case 3:
                    if (!redoStack.isEmpty()) {
                        String next = redoStack.pop();
                        undoStack.push(next);
                        text = next;
                        System.out.println("Redo successful!");
                    } else {
                        System.out.println("Nothing to redo!");
                    }
                    break;

                case 4:
                    System.out.println("\n--- Current Text ---");
                    System.out.println(text);
                    break;

                case 5:
                    System.out.println("Exiting Notepad...");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}