package undo_Redo;

class StackArray {
    private String[] arr;
    private int top;
    private int size;

    public StackArray(int size) {
        this.size = size;
        arr = new String[size];
        top = -1;
    }

    public void push(String val) {
        if (top < size - 1) {
            arr[++top] = val;
        } else {
            System.out.println("Stack Overflow!");
        }
    }

    public String pop() {
        if (isEmpty()) {
            return null;
        }
        return arr[top--];
    }

    public String peek() {
        if (isEmpty()) return null;
        return arr[top];
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void clear() {
        top = -1;
    }
}
