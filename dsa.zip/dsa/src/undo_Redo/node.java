package undo_Redo;

public class node {
    String text;
    node next;
    node(String text){
        this.text=text;
        this.next=null;
    }
}
