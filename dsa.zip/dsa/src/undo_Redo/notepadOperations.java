package undo_Redo;
import java.util.Scanner;

public class notepadOperations {
    public static void main(String[] args) {
        stack undo = new stack();
        stack redo = new stack();
        Scanner sc = new Scanner(System.in);
        String text = "";

        undo.push(new node(text)); // initial empty state

        while (true) {
            System.out.println("\n==== MENU DRIVEN NOTEPAD ====");
            System.out.println("1. Write text");
            System.out.println("2. Undo");
            System.out.println("3. Redo");
            System.out.println("4. Show current text");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter text to append: ");
                    String ntext = sc.nextLine();
                    text += ntext;
                    undo.push(new node(text));
                    redo.clear();
                    break;

                case 2:
                    node undone = undo.pop();
                    if (!undo.isEmpty()) {
                        redo.push(undone);
                        text = undo.peek().text;
                        System.out.println("Undo successful!");
                    } else {
                        undo.push(undone); // restore last
                        System.out.println("Nothing to undo!");
                    }
                    break;

                case 3:
                    if (!redo.isEmpty()) {
                        node redone = redo.pop();
                        undo.push(redone);
                        text = redone.text;
                        System.out.println("Redo successful!");
                    } else {
                        System.out.println("Nothing to redo!");
                    }
                    break;

                case 4:
                    System.out.println("\n--- Current Text ---");
                    System.out.println(text);
                    break;

                case 5:
                    System.out.println("Exiting Notepad...");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}