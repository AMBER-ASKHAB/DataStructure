package undo_Redo;

class stack {
    node top;

    public void push(node newNode) {
        // Always create a fresh copy so text isn’t lost
        node copy = new node(newNode.text);
        copy.next = top;
        top = copy;
    }

    public node pop() {
        if (top == null) return null;
        node temp = top;
        top = top.next;
        return temp;
    }

    public node peek() {
        return top;
    }

    public boolean isEmpty() {
        return top == null;
    }

    public void clear() {
        top = null;
    }
}