package week8_lab1_priorityQueue;

public class BloodBankSystem {
    Queue q=new Queue();
    public void addreq(request r)
    {
        q.enqueue(r);
    }
    public int serveRequest()
    {
       int retval= q.dequeue();
       return  retval;
    }
    void displayRequestbyType(String type)
    {
        q.displaybyType(type);
    }
    void displayall()
    {
        q.displayall();
    }
}
