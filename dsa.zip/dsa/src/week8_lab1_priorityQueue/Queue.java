package week8_lab1_priorityQueue;

public class Queue {
    request start;
    request end;
    public void enqueue(request x)
    {
        if(start==null)
        {
            start=x;
            end=x;
        }else
        {
            request temp=start;
            request ntemp=start;
            while(temp.next!=null)
            {
                if(temp.pn>ntemp.pn)
                    ntemp=temp;

                temp=temp.next;
            }
            end.next=ntemp;
            end=x;
        }
    }
     public  int dequeue()
     {
         if(start==null)
         {
             System.out.println("Queue is empty");
             end=null;
         }else
             start=start.next;
         return start.req_id;

     }
     public void displayall()
     {
         request temp=start;
         while(temp!=null)
         {
             System.out.println(temp.req_id);
             temp=temp.next;
         }
     }
    public void displaybyType(String type)
    {
        int f=0;
        request temp=start;
        while(temp!=null)
        {
            if(temp.bloodType.equals(type))
            {
                System.out.println(temp.req_id);
                f=1;
                break;
            }
            temp=temp.next;
        }
        if(f==0)
        System.out.println("nothing to display" );
    }
}
