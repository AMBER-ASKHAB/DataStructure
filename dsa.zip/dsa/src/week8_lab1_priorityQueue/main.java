package week8_lab1_priorityQueue;

import java.util.Scanner;

public class main {
    static void main(String[] args) {
        BloodBankSystem b=new BloodBankSystem();
        Scanner sc=new Scanner(System.in);

        int choice;
        do {
        System.out.println("1. AddRequest \n2. DisplayRequestby blood type  \n3. DisplayAllRequest \n4. servereq");
         choice=sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Enter request number");
                    int rno=sc.nextInt();
                    System.out.println("Enter blood type");
                    String blood=sc.next();
                    System.out.println("Enter priorityNumber");
                    int pno=sc.nextInt();
                    request Nreq=new request(rno,blood,pno);
                    b.addreq(Nreq);
                    break;

                    case 2:System.out.println("Enter blood type");
                    String bloodtype=sc.next();
                    b.displayRequestbyType(bloodtype);
                    break;

                    case 3:System.out.println("diaplayall");
                    b.displayall();
                    break;

                    case 4:b.serveRequest();
                    break;
                    default:System.out.println("Wrong choice");
            }
        }while(choice<=4);

    }
}
