package week8_lab1_priorityQueue;

public class request {
    int req_id;
    request next;
    String bloodType;
    int pn;
    request(int id,String bloodType,int pn)
    {
        req_id = id;
        this.bloodType = bloodType;
        this.pn = pn;
    }
}
