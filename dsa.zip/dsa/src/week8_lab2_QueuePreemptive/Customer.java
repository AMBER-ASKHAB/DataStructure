package week8_lab2_QueuePreemptive;

public class Customer {
    int id;
    String name;
    int totaltime=0;
    int remainingTime=0;
    Customer next;

    Customer(int id, String name) {
        this.id = id;
        this.name = name;
    }
}
