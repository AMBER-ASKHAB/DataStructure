package week8_lab2_QueuePreemptive;

public class QueueCC {
    private Customer start;
    private Customer end;
    private int timeQuantum = 5;
    private int totalServed = 0;

    public void enqueue(Customer x) {
        if (x == null) return;

        x.next = null;
        if (start == null) {
            start = end = x;
        } else {
            end.next = x;
            end = x;
        }
        System.out.println("Customer " + x.id + " (" + x.name + ") added ");
    }

    public Customer dequeue() {
        if (start == null) {
            return null;
        }
        Customer removed = start;
        start = start.next;
        if (start == null)
            end = null;

        removed.next = null;
        return removed;
    }
    public boolean isEmpty() {
        return start == null;
    }
    public void displayAll() {
        if (isEmpty()) {
            System.out.println("Queue is empty!");
            return;
        }

        Customer temp = start;
        while (temp != null) {
            System.out.println("ID: " + temp.id + ", Name: " + temp.name + ", Remaining Time: " + temp.remainingTime);
            temp = temp.next;
        }
    }

    public void startService() {
        System.out.println("\n===  Round Robin ===");

        while (!isEmpty()) {
            Customer current = dequeue();

            System.out.println("\nServing Customer " + current.id );
            if (current.remainingTime > timeQuantum) {
                current.remainingTime -= timeQuantum;
                System.out.println("Served for " + timeQuantum + " Remaining time: " + current.remainingTime);
                enqueue(current);
            } else {
                System.out.println("Service completed for Customer " + current.name);
                totalServed++;
            }
            displayAll();
        }

        System.out.println("\n=== All customers have been served! ===");
    }

    public void displaySummary() {
        System.out.println("\n=== Service Summary ===");
        System.out.println("Total Customers Served: " + totalServed);
        System.out.println("Time Quantum Used: " + timeQuantum + " units");
    }
}
