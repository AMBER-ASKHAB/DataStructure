package week8_lab2_QueuePreemptive;

public class callcenter {
    QueueCC q;
    int timeQuatum=5;

    public void addCustomer(Customer c)
    {
        q.enqueue(c);
    }
    public void startService()
    {
         q.startService();
    }
    public void displaySummary()
    {
        q.displaySummary();
    }
}
