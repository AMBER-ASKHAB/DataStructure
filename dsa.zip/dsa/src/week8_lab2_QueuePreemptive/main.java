package week8_lab2_QueuePreemptive;

import week8_lab1_priorityQueue.request;

import java.util.Scanner;

public class main {
    public static void main(String[] args)
    {
        callcenter c=new callcenter();
        Scanner sc=new Scanner(System.in);

        int choice;
        do {
            System.out.println("1. AddCustomer \n2. Startseervice  \n3. DisplayAllRequest ");
            choice=sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Name");
                    String name=sc.next();
                    System.out.println("Id");
                    int id=sc.nextInt();
                    Customer Nreq=new Customer(id,name);
                    c.addCustomer(Nreq);
                    break;

                case 2:c.startService();
                    break;

                case 3:c.displaySummary();
                    break;

                default:System.out.println("Wrong choice");
            }
        }while(choice<=3);

    }
    }

